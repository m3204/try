

import requests
# import json 
import pandas as pd 
import datetime
import dateutil 
# import quantstats as qs
import numpy as np
from termcolor import colored
from tabulate import tabulate
from scipy import stats
from scipy.stats import gaussian_kde
from statsmodels.tsa.stattools import adfuller
# from statsmodels.nonparametric.kde import KDEUnivariate
# from sklearn.neighbors import KernelDensity
import seaborn as sns
# from tqdm import tqdm
import matplotlib.pyplot as plt
import joblib as jb
import math 

try:
    import talib as ta
except Exception as e:
    Warning("To use Indicators, Kindly Install TALIB....")
    ta = None


# from .resample_df import Resample


# resample = Resample()

class ApiCall:

    def __init__(self, exchange = 'NSE', data_type = 'Equity', adjusted = True, tv_data = True, bhavcopy_type = 'FO', see_orginal_df = False):
        """
        Initialize the ApiCall object with the specified parameters.

        Parameters:
        
        exchange (str): The exchange to fetch data from (default 'NSE').
        
        data_type (str): The type of data to fetch ('Equity', 'Options', 'Futures', 'Bhavcopy', 'ExpiryDates') (default 'Equity').
        
        adjusted (bool): Whether to fetch adjusted data (default True).
        
        tv_data (bool): Whether to use TradingView data (default True).
        
        bhavcopy_type (str): The type of bhavcopy to fetch (default 'FO').
        
        see_orginal_df (bool): Whether to see the original DataFrame (default False).
        """

        if data_type == 'ExpiryDates':
            self.url = rf"http://192.168.101.61/DataLakeAPI/v1/{exchange}/ExpiryDates"
        else:
            if data_type == 'Equity' and not adjusted and exchange == 'NSE':
                self.url = rf"http://192.168.101.61/DataLakeAPI/v1/{exchange}/{data_type}/NonAdjusted/Ticker"
            elif data_type in ['Equity', 'Options', 'Futures']:
                if tv_data and data_type == 'Equity' and exchange == 'NSE':
                    self.url = rf"http://192.168.101.61/DataLakeAPI/v1/{exchange}/{data_type}/TradingView/Ticker"
                
                else:
                    self.url = rf"http://192.168.101.61/DataLakeAPI/v1/{exchange}/{data_type}/Ticker"
            
            elif data_type == 'Bhavcopy':
                self.url = rf"http://192.168.101.61/DataLakeAPI/v1/{data_type}/{exchange}/{bhavcopy_type}"
        

        self.exchange = exchange
        self.data_type = data_type
        self.bhavcopy_type = bhavcopy_type
        self.query_dict = {}
        self.df = pd.DataFrame()
        self.see_orginal_df = see_orginal_df
        self.special_dates = pd.to_datetime(pd.Series(['2011-10-26', '2012-11-13', '2013-11-03','2014-10-23','2015-11-11', '2016-10-30', '2017-10-19', '2018-11-07', 
             '2019-10-27', '2020-11-14', '2021-11-04', '2022-10-24', '2023-11-12', '2021-02-24', '2024-03-02', '2024-05-18', '2024-11-01'])).dt.date.values
    
    def frwd_fill(self, df, method = 'ffill',  freq = '1min', label = 'right', origin = '09:15:00',
                  agg_func={'Expiry_date' : 'last', 'StrikePrice' : 'last','Open':'first','High':'max','Low': 'min','Close' : 'last', 'Volume':'sum', 'OpenInterest' : 'last','CE/PE' : 'last'}, 
                  direct = False, groupby_key_list = None, datetime_index=False, 
                  two_times_fill = False, no_fill = False, remove_time_bool = False, remove_first_time = 0, remove_last_time = 0):
        df = df.copy()
        # df.index = pd.to_datetime(df['Datetime'])
        # df.set_index('Datetime', inplace=True)
        # if direct:
        #     try:
        #         df.set_index('Datetime', inplace=True)
        #     except:
        #         pass strikePrice
            
        #     df = df.resample('1t').agg(agg_func).ffill()
        #     return df.between_time('09:15', '15:30')
        
        if len(freq) == 2 and freq[-1] in ['d', 'D', 'm', 'M', 'q', 'Q', 'w', 'W']:
            resample_ge_than_1d = True
        else:
            resample_ge_than_1d = False

        if groupby_key_list == None:
            if not resample_ge_than_1d:
                try:
                    groups = df.groupby([df.index.date, df['expiryDate'], df['strikePrice'], df['optionType'], df['symbol']], group_keys = True)
                except:
                    groups = df.groupby([df.tradeDate.dt.date, df['expiryDate'], df['strikePrice'], df['optionType'],df['symbol']], group_keys = True)
            elif resample_ge_than_1d:
                groups = df.groupby([df['expiryDate'], df['strikePrice'], df['optionType'], df['symbol']], group_keys = True)
        
        elif ((groupby_key_list != None and self.data_type != 'Equity') or 
              (groupby_key_list != None and not resample_ge_than_1d and self.data_type == 'Equity')):
            groups = df.groupby(groupby_key_list, group_keys = True)
        
        elif self.data_type == 'Equity' and resample_ge_than_1d:
            try:
                df.set_index('tradeDate', inplace=True)
            except:
                pass 

            df.sort_index(inplace=True)
            if not datetime_index:
                return df.resample(freq).agg(agg_func).reset_index().dropna(subset = ['open', 'high', 'low', 'close']).reset_index(drop=True)
            
            if datetime_index:
                return df.resample(freq).agg(agg_func).dropna(subset = ['open', 'high', 'low', 'close'])

        else:
            print('Issue')
            return None
        
        def resmpl(group):
            try:
                group.set_index('tradeDate', inplace=True)
                
                # del agg_func['tradeDate']
            except:
                pass
            group.sort_index(inplace=True)
            
            if remove_time_bool:
                if len(pd.Series(group.index.date).unique()) == 1:
                    group = group.loc[(group.index >= group.index[0] + pd.Timedelta(minutes=remove_first_time)) & 
                            (group.index <= group.index[-1] - pd.Timedelta(minutes=remove_last_time))].copy()
                    
                else:
                    temp_grps = group.groupby([group.index.date])
                    group = temp_grps.apply(lambda x : x.loc[(x.index >= x.index[0] + pd.Timedelta(minutes=remove_first_time)) & 
                            (x.index <= x.index[-1] - pd.Timedelta(minutes=remove_last_time))])
            # if self.exchange == 'NYSE':
            #     origin = '09:30:00'
            if not group.empty:
                if not resample_ge_than_1d:
                    group = group.resample(freq, label = label, origin = str(group.index.date[0]) + ' ' + origin).agg(agg_func)
                elif resample_ge_than_1d:
                    group = group.resample(freq).agg(agg_func)

                if no_fill:
                    return group.reset_index()
                
                if not two_times_fill:
                    if method == 'ffill':
                        group.ffill(inplace=True)
                    elif method == 'bfill':
                        group.bfill(inplace=True)
                    
                
                elif two_times_fill and method == 'ffill':
                    group.ffill(inplace=True)
                    group.bfill(inplace=True)
                
                elif two_times_fill and method == 'bfill':
                    group.bfill(inplace=True)
                    group.ffill(inplace=True)
                
                return group.reset_index()
            
        df = groups.apply(resmpl).reset_index(drop=True)
        df = df.dropna(subset = ['open', 'high', 'low', 'close']).reset_index(drop=True)
        
        if datetime_index:
            df.set_index('tradeDate', inplace=True)
        
        return df
    def request_body(self, symbol : list, start_date = None, end_date = None, 
                     start_expiry = None, end_expiry = None, 
                     option_type : str = None, 
                     strike_price : list = None,
                     till_today  : bool = False, 
                     greeks_added : bool = False,
                     start_iv : float = None,
                    end_iv : float = None,
                    start_delta : float = None,
                    end_delta : float = None,
                    start_dte : float = None,
                    end_dte : float = None
                     ):
        if end_date is None:
            if not till_today:
                end_date = start_date
            else:
                end_date = pd.Timestamp.today()

        if end_expiry is None:
            end_expiry = start_expiry 


        if isinstance(start_date, datetime.datetime) or isinstance(start_date, pd.Timestamp) or isinstance(start_date, datetime.date):
            start_date = start_date.strftime('%d-%m-%Y')
            # end_date = end_date.strftime('%d-%m-%Y')
        else:
            # if start_date is not None and end_date is not None:
            if start_date is not None :
                try:
                    start_date = pd.to_datetime(start_date, format = '%d-%m-%Y')
                    start_date = start_date.strftime('%d-%m-%Y')

                    # end_date = pd.to_datetime(end_date, format='%d-%m-%Y')
                    # end_date = end_date.strftime('%d-%m-%Y')
                except:
                    try:
                        start_date = pd.to_datetime(start_date, format = '%d/%m/%Y')
                        start_date = start_date.strftime('%d-%m-%Y')

                        # end_date = pd.to_datetime(end_date, format='%d/%m/%Y')
                        # end_date = end_date.strftime('%d-%m-%Y')

                    except:
                        start_date = dateutil.parser.parse(start_date)
                        start_date = start_date.strftime('%d-%m-%Y')

                        # end_date = dateutil.parser.parse(end_date)
                        # end_date = end_date.strftime('%d-%m-%Y')
        
        if isinstance(end_date, datetime.datetime) or isinstance(end_date, pd.Timestamp) or isinstance(end_date, datetime.date):
            end_date = end_date.strftime('%d-%m-%Y')
        else:
            if end_date is not None :
                try:
                    end_date = pd.to_datetime(end_date, format='%d-%m-%Y')
                    end_date = end_date.strftime('%d-%m-%Y')
                except:
                    try:
                        end_date = pd.to_datetime(end_date, format='%d/%m/%Y')
                        end_date = end_date.strftime('%d-%m-%Y')

                    except:
                        end_date = dateutil.parser.parse(end_date)
                        end_date = end_date.strftime('%d-%m-%Y')

                    
        if start_expiry is not None and end_expiry is not None:
            if isinstance(start_expiry, datetime.datetime) or isinstance(start_expiry, pd.Timestamp) or isinstance(start_expiry, datetime.date):
                start_expiry = start_expiry.strftime('%d-%m-%Y')
                end_expiry = end_expiry.strftime('%d-%m-%Y')
            
            else:
                try:

                    start_expiry = pd.to_datetime(start_expiry, format = '%d-%m-%Y')
                    start_expiry = start_expiry.strftime('%d-%m-%Y')

                    end_expiry = pd.to_datetime(end_expiry, format='%d-%m-%Y')
                    end_expiry = end_expiry.strftime('%d-%m-%Y')
                except:
                    try:
                        start_expiry = pd.to_datetime(start_expiry, format = '%d/%m/%Y')
                        start_expiry = start_expiry.strftime('%d-%m-%Y')

                        end_expiry = pd.to_datetime(end_expiry, format='%d/%m/%Y')
                        end_expiry = end_expiry.strftime('%d-%m-%Y')

                    except:
                        start_expiry = dateutil.parser.parse(start_expiry)
                        start_expiry = start_expiry.strftime('%d-%m-%Y')

                        end_expiry = dateutil.parser.parse(end_expiry)
                        end_expiry = end_expiry.strftime('%d-%m-%Y')

        if greeks_added:

            if end_iv is None:
                end_iv = start_iv
            if end_delta is None:
                end_delta = start_delta
            if end_dte is None:
                end_dte = start_dte

            return {
            "tradeFromDate": start_date,
            "tradeToDate": end_date,
            "symbol": symbol,
            "expFromDate": start_expiry,
            "expToDate": end_expiry,
            "optionType": option_type,
            "strikePrices": strike_price, 
            "ivFrom":start_iv,
            "ivTo": end_iv,
            "deltaFrom": start_delta,
            "deltaTo": end_delta,
            "dteFrom":start_dte,
            "dteTo": end_dte
            }

        return {
            "tradeFromDate": start_date,
            "tradeToDate": end_date,
            "symbol": symbol,
            "expFromDate": start_expiry,
            "expToDate": end_expiry,
            "optionType": option_type,
            "strikePrices": strike_price
        }
    

    def get_data(self, symbol : list, 
                 start_date = None, end_date = None, 
                 start_expiry = None, end_expiry = None, 
                 option_type : str = None, 
                 strike_price : list = None, 
                 segment = 'F',
                 greeks_added = False, 
                 start_iv : float = None,
                 end_iv : float = None,
                 start_delta : float = None,
                 end_delta : float = None,
                 start_dte : float = None,
                 end_dte : float = None,
                 Datetime = None, 
                 Time = None,
                 time_above = True, 
                 datetime_index = False, 
                 ceil = False,
                 floor = False,
                 normal_columns = True,
                 till_today = False, 
                 fill_nan = False,
                 resample_bool : bool = False,
                 resample_freq : str = '1min',
                 label : str = 'right',
                 no_fill = False,
                 origin = '09:15:00',
                #  resample_ge_than_1d = False, 
                #  format_59 = True, 
                 remove_time_bool = False,
                 remove_first_time = 0,
                 remove_last_time = 0,
                 time_filter = True, 
                 time_filter_start = '09:15:00', 
                 time_filter_end = '15:29:00', 
                 remove_special_dates = False
                #  two_times_fill = False,
                #  method = 'ffill

                 ):# -> DataFrame | Any:
        
        """
        symbol (list):
        
        A list of symbols (e.g., stock or option tickers) for which data is to be retrieved.
        Affects: Determines the financial instruments for which data will be fetched.

        start_date (str, optional):
        
        The start date for the data retrieval period in YYYY-MM-DD format.
        Affects: Limits the data to records from this date onward.

        end_date (str, optional):
        
        The end date for the data retrieval period in YYYY-MM-DD format.
        Affects: Limits the data to records up to this date.

        start_expiry (str, optional):
        
        The start date for the option expiry period in YYYY-MM-DD format.
        Affects: Limits the data to options expiring from this date onward.

        end_expiry (str, optional):
        
        The end date for the option expiry period in YYYY-MM-DD format.
        Affects: Limits the data to options expiring up to this date.

        option_type (str, optional):
        
        Type of option ('call' or 'put').
        Affects: Filters the data to include only the specified type of options.

        strike_price (list, optional):
        
        A list of strike prices for options.
        Affects: Filters the data to include only options with the specified strike prices.

        segment (str, default='F'):
        
        The market segment to which the request pertains (e.g., 'F' for futures, 'O' for options).
        Affects: Determines the market segment from which data will be retrieved.

        greeks_added (bool, default=False):
        
        If true, adds greeks columns to the DataFrame.
        Affects: Adds greeks columns to the DataFrame.

        start_iv (float, optional):
        
        The start value for the implied volatility range.
        Affects: Filters the data to include only options with implied volatilities within the specified range.

        end_iv (float, optional):
        
        The end value for the implied volatility range.
        Affects: Filters the data to include only options with implied volatilities within the specified range.

        start_delta (float, optional):
        
        The start value for the delta range.
        Affects: Filters the data to include only options with deltas within the specified range.

        end_delta (float, optional):
        
        The end value for the delta range.
        Affects: Filters the data to include only options with deltas within the specified range.

        start_dte (float, optional):
        
        The start value for the days to expiry range.
        Affects: Filters the data to include only options with days to expiry within the specified range.

        end_dte (float, optional):
        
        The end value for the days to expiry range.
        Affects: Filters the data to include only options with days to expiry within the specified range.

        Datetime (list or str, optional):
        
        Specific datetime(s) to filter the data. Can be a single datetime or a list of two datetimes to define a range.
        Affects: Filters the data to include only records within the specified datetime range or at the specific datetime.

        Time (list or str, optional):
        
        Specific time(s) to filter the data. Can be a single time or a list of two times to define a range.
        Affects: Filters the data to include only records within the specified time range or at the specific time.

        time_above (bool, default=True):
        
        If true, filters the data to include records from the specified datetime/time onward.
        Affects: Determines the direction of filtering for the datetime/time range.

        datetime_index (bool, default=False):
        
        If true, sets the 'Datetime' column as the index of the DataFrame.
        Affects: Changes the DataFrame's index to 'Datetime' or 'tradeDate'.

        ceil (bool, default=False):
        
        If true, rounds the 'tradeDate' column values up to the nearest minute.
        Affects: Adjusts the timestamps to the nearest future minute.

        floor (bool, default=False):
        
        If true, rounds the 'tradeDate' column values down to the nearest minute.
        Affects: Adjusts the timestamps to the nearest past minute.

        normal_columns (bool, default=True):
        
        If true, renames columns to more user-friendly names based on the data type.
        Affects: Makes the DataFrame's column names more understandable.

        till_today (bool, default=False):
        
        If true, includes data up to the current date.
        Affects: Extends the end date to the current date if no end_date is specified.

        fill_nan (bool, default=False):
        
        If true, fills NaN values in the DataFrame.
        Affects: Ensures that there are no missing values in the returned data.

        resample_bool (bool, default=False):
        
        If true, resamples the data at a specified frequency.
        Affects: Aggregates the data to a new frequency specified by 
        resample_freq.

        resample_freq (str, default='1min'):
        
        The frequency for resampling the data (e.g., '1min' for 1-minute intervals).
        Affects: Defines the new frequency for the resampled data.

        label (str, default='right'):
        
        The label parameter for the resampling function ('right' or 'left').
        Affects: Determines how the aggregated data is labeled (aligned to the right or left).

        no_fill (bool, default=False):
        
        If true, prevents forward-filling of NaN values.
        Affects: Controls whether NaN values are filled with the previous valid data point.

        remove_time_bool (bool, default=False):
        
        If true, removes the time component from the date column.
        Affects: Keeps only the date part in the 'Datetime' or 'tradeDate' column.

        remove_first_time (int, default=0):
        
        Removes the first N minutes of data.
        Affects: Filters out the initial minutes of each trading day.

        remove_last_time (int, default=0):
        
        Removes the last N minutes of data.
        Affects: Filters out the final minutes of each trading day.

        time_filter (bool, default=True):
        
        If true, filters the data based on the specified time range.
        Affects: Limits the data to the specified trading hours.

        time_filter_start (str, default='09:15:00'):
        
        The start time for the time filter in HH:MM
        format.
        Affects: Sets the beginning of the trading hours for filtering.

        time_filter_end (str, default='15:29:00'):
        
        The end time for the time filter in HH:MM
        format.
        Affects: Sets the end of the trading hours for filtering.

        remove_special_dates (bool, default=False):
        
        If true, removes data from special dates (e.g., holidays or other non-trading days).
        Affects: Excludes data from specified special dates.
        Functionality and Output:

        ExpiryDates Data Retrieval:
        
        If self.data_type is 'ExpiryDates', the method sends a request for expiry dates data and returns a DataFrame with the 'Date' column.
        Other Data Types:

        For other data types, it builds a query dictionary based on the arguments provided and sends a request to the API.
        Handles pagination by fetching and concatenating data from multiple pages if needed.

        Applies time filters, resampling, NaN filling, and column renaming based on the arguments.
        Final Data Processing:

        The data is filtered and processed based on the specified arguments and returned as a pandas DataFrame.

        Usage Example:

        api_call = ApiCall(exchange = 'NSE', data_type = 'Equity', tv_data = True)
        
        data = api_call.get_data(symbol=['NIFTY_50'], start_date='2023-01-01', end_date='2023-01-31', resample_bool=True, resample_freq='5min')

        In this example, the get_data method retrieves 5-minute resampled data for the symbol 'NIFTY_50' for January 2023.
        
        
        """
        
        # return query_dict
        # greeks_added = False
        if self.data_type == 'Options' and symbol[0] in ['BANKNIFTY', 'NIFTY'] and self.exchange == 'NSE' and greeks_added:
            # greeks_added = True
            self.url = rf"http://192.168.101.61/DataLakeAPI/v1/NSE/Options/Index/{symbol[0].capitalize()}/Ticker"

        if self.data_type == 'ExpiryDates':
            if type(symbol) == list:
                response = requests.post(self.url, json = {"symbol":symbol[0],"segment":segment})
            else:
                response = requests.post(self.url, json = {"symbol":symbol,"segment":segment})

            df = pd.DataFrame(pd.DataFrame(response.json())['data'].to_list())
            df.columns = ['Date']
            df['Date'] = pd.to_datetime(df['Date']).dt.tz_localize(None)
            return df.sort_values(by=['Date'])

        self.query_dict = self.request_body(symbol = symbol, 
                                       start_date = start_date, 
                                       end_date = end_date, 
                                       start_expiry = start_expiry, 
                                       end_expiry = end_expiry, 
                                       option_type = option_type, 
                                       strike_price = strike_price, 
                                       till_today=till_today, 
                                       greeks_added = greeks_added, 
                                       start_iv = start_iv,
                                       end_iv = end_iv,
                                       start_delta = start_delta,
                                       end_delta = end_delta,
                                       start_dte = start_dte,
                                       end_dte = end_dte
                                       )
        
        response = requests.post(self.url, json = self.query_dict)
        try:
            df = pd.DataFrame(pd.DataFrame(response.json())['data'].to_list())
        except:

            if response.status_code == 200:
                if response.json()['httpCode'] in [204, 400, 404, 500]:
                    raise Exception(f"{response.json()['message']} : {self.query_dict}")

                if response.json()['httpCode'] == 204:
                    raise ValueError(f"No record found in the database for requested query : {self.query_dict}")
                
                if response.json()['httpCode'] == 400:
                    raise Exception(f"Invalid query : {self.query_dict}")
                
                if response.json()['httpCode'] == 404:
                    raise Exception(f"Page Not found : {self.query_dict}")
                
                if response.json()['httpCode'] == 500:
                    raise Exception(f"Internal Server Error (Please connect the IT Team): {self.query_dict}")
                
                else:
                    raise Exception(f"Something went wrong : {self.query_dict}")
            else:
                raise Exception(f"Something went wrong : {self.query_dict}")
        
        page_count = response.json()['totalPageCount']
        df['tradeDate'] = pd.to_datetime(df['tradeDate']).dt.tz_localize(None)

        if self.data_type in ['Options', 'Futures']:
            df['expiryDate'] = pd.to_datetime(df['expiryDate']).dt.tz_localize(None)

        if page_count == 2:
            temp_url = self.url + f'?page=2'
            response = requests.post(temp_url, json = self.query_dict)
            dft = pd.DataFrame(pd.DataFrame(response.json())['data'].to_list())
            dft['tradeDate'] = pd.to_datetime(dft['tradeDate']).dt.tz_localize(None)

            if self.data_type in ['Options', 'Futures']:
                dft['expiryDate'] = pd.to_datetime(dft['expiryDate']).dt.tz_localize(None)

            df = pd.concat([df, dft], ignore_index = True)


        if page_count > 2:
            for p in range(2, page_count + 1):

                temp_url =  self.url + f'?page={p}'
                # return query_dict, p, self.url
                response = requests.post(temp_url, json = self.query_dict)
                # return response
                dft = pd.DataFrame(pd.DataFrame(response.json())['data'].to_list())
                dft['tradeDate'] = pd.to_datetime(dft['tradeDate']).dt.tz_localize(None)

                if self.data_type in ['Options', 'Futures']:
                    dft['expiryDate'] = pd.to_datetime(dft['expiryDate']).dt.tz_localize(None)

                df = pd.concat([df, dft], ignore_index = True)

        # if resample_bool:
        #     if self.data_type in ['Options']:
        #         agg_func = {}
        #         for k in df.columns:
        #             if k == 'open':
        #                 agg_func[k] = 'first'
        #             elif k == 'high':
        #                 agg_func[k] = 'max'
        #             elif k == 'low':
        #                 agg_func[k] = 'min'
        #             elif k == 'close':
        #                 agg_func[k] = 'last'
        #             else:
        #                 agg_func[k] = 'first'
        #         resample.resample_options(df, freq = resample_freq, label = 'right')
        
        if self.see_orginal_df:
            self.df  = df.copy()

        if self.data_type != 'Bhavcopy':
            if time_filter:
                if (df.tradeDate.dt.date.isin(self.special_dates)).any():
                    temp_df = df.loc[(df['tradeDate'].dt.date.isin(self.special_dates))].copy()
                    clean_df = df.loc[~(df['tradeDate'].dt.date.isin(self.special_dates))].copy()
                    clean_df = clean_df.loc[(clean_df['tradeDate'].dt.time >= pd.to_datetime(time_filter_start).time()) &
                                                (clean_df['tradeDate'].dt.time <= pd.to_datetime(time_filter_end).time())].copy()
                    # if self.exchange == 'NYSE':
                    #         clean_df = clean_df.loc[(clean_df['tradeDate'].dt.time >= pd.to_datetime('09:30:00').time()) &
                    #                             (clean_df['tradeDate'].dt.time <= pd.to_datetime('16:00:00').time())].copy()
                    # else:    
                    #     clean_df = clean_df.loc[(clean_df['tradeDate'].dt.time >= pd.to_datetime('09:15:00').time()) &
                    #                             (clean_df['tradeDate'].dt.time <= pd.to_datetime('15:29:59').time())].copy()
                            
                    df = pd.concat([clean_df, temp_df]).sort_values(by=['tradeDate']).reset_index(drop=True)
            
                else:
                    df = df.loc[(df['tradeDate'].dt.time >= pd.to_datetime(time_filter_start).time()) &
                                                (df['tradeDate'].dt.time <= pd.to_datetime(time_filter_end).time())].copy()
                    # if self.exchange == 'NYSE':

                    #     df = df.loc[(df['tradeDate'].dt.time >= pd.to_datetime('09:30:00').time()) &
                    #                             (df['tradeDate'].dt.time <= pd.to_datetime('16:00:00').time())].copy()
                    # else:
                    #     df = df.loc[(df['tradeDate'].dt.time >= pd.to_datetime('09:15:00').time()) &
                    #                             (df['tradeDate'].dt.time <= pd.to_datetime('15:29:59').time())].copy()
                
            
            if not df.empty and (fill_nan or resample_bool) and self.data_type == 'Options':
                # agg_func = {}
                # for k in df.columns:
                #     if k == 'open':
                #         agg_func[k] = 'first'
                #     elif k == 'high':
                #         agg_func[k] = 'max'
                #     elif k == 'low':
                #         agg_func[k] = 'min'
                #     elif k == 'close':
                #         agg_func[k] = 'last'
                #     else:
                #         agg_func[k] = 'first'
                if not greeks_added:
                    agg_func = {'open': 'first', 'high': 'max', 'low': 'min', 'close': 'last', 'volume': 'sum',
                                'openInterest': 'last', 'expiryDate': 'first', 'strikePrice': 'first', 
                                'optionType': 'first', 'time' : 'first', 'symbol' : 'first'}
                elif greeks_added:
                    agg_func = {'open': 'first', 'high': 'max', 'low': 'min', 'close': 'last', 'volume': 'sum',
                                'openInterest': 'last', 'expiryDate': 'first', 'strikePrice': 'first', 
                                'optionType': 'first', 'time' : 'first', 'symbol' : 'first', 
                                'iv' : 'last', 'spotPrice' : 'last', 'dte' : 'last', 
                                'delta' : 'last', 'gamma' : 'last', 'vega' : 'last', 
                                'theta' : 'last', 'rho' : 'last'}
                        
                df = self.frwd_fill(df, two_times_fill=False, agg_func=agg_func, origin=origin,
                                    freq=resample_freq, label=label, remove_time_bool=remove_time_bool, 
                                    remove_first_time=remove_first_time, remove_last_time=remove_last_time)
                
            if not df.empty and (fill_nan or resample_bool)and self.data_type == 'Equity':
                agg_func = {'open': 'first', 'high': 'max', 'low': 'min', 'close': 'last', 'volume': 'sum', 'time' : 'first', 'symbol' : 'first'}
                df = self.frwd_fill(df, two_times_fill=False, no_fill=no_fill, 
                                    agg_func=agg_func, 
                                    freq=resample_freq, label=label, origin=origin,
                                    groupby_key_list=[df.tradeDate.dt.date], 
                                    remove_time_bool=remove_time_bool, 
                                    remove_first_time=remove_first_time, remove_last_time=remove_last_time)
                
            if not df.empty and (fill_nan or resample_bool)and self.data_type == 'Futures':
                try:
                    agg_func = {'open': 'first', 'high': 'max', 'low': 'min', 'close': 'last', 'volume': 'sum', 
                                'time' : 'first', 'expiryDate': 'first', 'openInterest': 'last', 
                                'contractSize': 'first', 'symbol' : 'first'}
                    df = self.frwd_fill(df, two_times_fill=False, agg_func=agg_func, 
                                        freq=resample_freq, label=label, origin=origin,
                                        groupby_key_list=[df.tradeDate.dt.date, df.expiryDate], 
                                        remove_time_bool=remove_time_bool, 
                                    remove_first_time=remove_first_time, remove_last_time=remove_last_time)

                except:
                    agg_func = {'open': 'first', 'high': 'max', 'low': 'min', 'close': 'last', 'volume': 'sum', 
                                'time' : 'first', 'expiryDate': 'first', 
                                'openInterest': 'last','symbol' : 'first'}
                    df = self.frwd_fill(df, two_times_fill=False, agg_func=agg_func, 
                                        freq=resample_freq, origin=origin,
                                        label=label, 
                                        groupby_key_list=[df.tradeDate.dt.date, df.expiryDate], 
                                        remove_time_bool=remove_time_bool, 
                                        remove_first_time=remove_first_time, remove_last_time=remove_last_time)
                

            # format_59 = False
            if not resample_bool:
                
                if ceil and not floor:
                    df['tradeDate'] = df['tradeDate'].dt.ceil('Min')
                
                elif not ceil and floor:
                    df['tradeDate'] = df['tradeDate'].dt.floor('Min')
                
                # elif not ceil and not floor:
                #     format_59 = True


            if Datetime != None:
                if type(Datetime) == list:
                    if len(Datetime) == 1:
                        try:
                            Datetime1 = pd.to_datetime(Datetime[0])
                        except:
                            pass

                        if time_above:
                            # if format_59:
                            #     df = df.loc[(df['tradeDate'] >= (Datetime1 - pd.Timedelta(seconds = 1)))]
                            # elif not format_59:
                            #     df = df.loc[(df['tradeDate'] >= Datetime1)]
                            df = df.loc[(df['tradeDate'] >= Datetime1)]

                        if not time_above:
                            # if format_59:
                            #     df = df.loc[(df['tradeDate'] <= (Datetime1 - pd.Timedelta(seconds = 1)))]
                            # elif not format_59:
                            #     df = df.loc[(df['tradeDate'] <= Datetime1)]
                            df = df.loc[(df['tradeDate'] <= Datetime1)]
                    
                    if len(Datetime) == 2:
                        try:
                            Datetime1 = pd.to_datetime(Datetime[0])
                            Datetime2 = pd.to_datetime(Datetime[1])
                        except:
                            pass
                        # if format_59:
                        #     df = df.loc[(df['tradeDate'] >= (Datetime1 - pd.Timedelta(seconds = 1))) & 
                        #                 (df['tradeDate'] <= (Datetime2 - pd.Timedelta(seconds = 1)))]   
                        # elif not format_59:
                        #     df = df.loc[(df['tradeDate'] >= Datetime1) & (df['tradeDate'] <= Datetime2)] 
                        df = df.loc[(df['tradeDate'] >= Datetime1) & (df['tradeDate'] <= Datetime2)] 

                else:
                    try:
                        Datetime = pd.to_datetime(Datetime)
                    except:
                        pass
                    # if format_59:
                    #     df = df.loc[(df['tradeDate'] == (Datetime - pd.Timedelta(seconds = 1)))]
                    # elif not format_59:
                    #     df = df.loc[(df['tradeDate'] == Datetime)]
                    df = df.loc[(df['tradeDate'] == Datetime)]

            if Time != None:
                if type(Time) == list:
                    if len(Time) == 1:
                        try:
                            Time1 = pd.to_datetime(Time[0])
                        except:
                            try:
                                Time1 = pd.to_datetime(Time[0].strftime('%H:%M:%S'))
                            except:
                                Time1 = Time[0]
                        if time_above:
                            
                            # if format_59:
                            #     df = df.loc[(df['tradeDate'].dt.time >= (Time1 - pd.Timedelta(seconds = 1)).time())]
                            # elif not format_59:
                            #     df = df.loc[(df['tradeDate'].dt.time >= Time1.time())]
                            df = df.loc[(df['tradeDate'].dt.time >= Time1.time())]
                        
                                
                        if not time_above:
                            # if format_59:
                            #     df = df.loc[(df['tradeDate'].dt.time <= (Time1 + pd.Timedelta(seconds = 1)).time())]
                            # else:
                            #     df = df.loc[(df['tradeDate'].dt.time <= Time1.time())]
                            df = df.loc[(df['tradeDate'].dt.time <= Time1.time())]
                    
                    if len(Time) == 2:
                        try:
                            Time1 = pd.to_datetime(Time[0])
                            Time2 = pd.to_datetime(Time[1])
                        except:
                            Time1 = Time[0]
                            Time2 = Time[1]
                            pass
                        # df = df.loc[(df['tradeDate'].dt.time >= (Time1 - pd.Timedelta(seconds = 1)).time()) & 
                        #             (df['tradeDate'].dt.time <= (Time2 + pd.Timedelta(seconds = 1)).time())]
                        df = df.loc[(df['tradeDate'].dt.time >= Time1.time()) &
                                    (df['tradeDate'].dt.time <= Time2.time())]
                else:
                    try:
                        Time = pd.to_datetime(Time).time()
                    except:
                        pass
                    # tdf = df.loc[(df['tradeDate'].dt.time == Time)]
                    # if tdf.empty:
                    # if format_59:
                    #     df = df.loc[(df['tradeDate'].dt.time) == (pd.Timestamp((Time.strftime('%H:%M:%S'))) - pd.Timedelta(seconds = 1)).time()]
                    # else:
                    #     df = df.loc[(df['tradeDate'].dt.time) == Time]
                    df = df.loc[(df['tradeDate'].dt.time) == Time]
                    # else:
                    #     df = tdf.copy()
            
        if normal_columns:
            if self.data_type == 'Options':
                df = df.rename(columns = {'tradeDate' : 'Datetime', 'expiryDate' : 'Expiry_date', 'open' : 'Open', 
                                     'high' : 'High', 'low' : 'Low', 'close' : 'Close', 'openInterest' : 'OpenInterest', 
                                     'optionType' : 'CE/PE', 'strikePrice' : 'StrikePrice', 'volume' : 'Volume'})
                
            elif self.data_type == 'Futures':
                df = df.rename(columns = {'tradeDate' : 'Datetime', 'expiryDate' : 'Expiry_date', 'open' : 'Open', 
                                     'high' : 'High', 'low' : 'Low', 'close' : 'Close','volume' : 'Volume'})
            
            elif self.data_type == 'Equity':
                df = df.rename(columns = {'tradeDate' : 'Datetime', 'open' : 'Open', 
                                     'high' : 'High', 'low' : 'Low', 'close' : 'Close', 'volume' : 'Volume'})
                
            elif self.data_type == 'Bhavcopy' :
                if self.bhavcopy_type == 'FO' and self.exchange == 'NSE':
                    df = df.rename(columns = {'instrument' : 'INSTRUMENT', 'symbol' : 'SYMBOL', 'expiryDate' : 'EXPIRY_DT', 
                                            'strikePrice' : 'STRIKE_PR', 'optionType' : 'OPTION_TYP',
                                            'open' : 'OPEN', 'high' : 'HIGH', 'low' : 'LOW', 'close' : 'CLOSE', 'last' : 'LAST', 
                                            'settlementPrice' : 'SETTLE_PR', 
                                            'tradedQuantity' : 'CONTRACTS', 'tradedAmount' : 'VAL_INLAKH', 
                                            'openInterest' : 'OPEN_INT', 'changeInOI' : 'CHG_IN_OI', 'tradeDate' : 'TIMESTAMP'})
                
                elif self.bhavcopy_type == 'FO' and self.exchange == 'MCX':
                    df = df.rename(columns = {'instrument' : 'INSTRUMENT', 'symbol' : 'SYMBOL', 'expiryDate' : 'EXPIRY_DT', 
                                            'strikePrice' : 'STRIKE_PR', 'optionType' : 'OPTION_TYP',
                                            'open' : 'OPEN', 'high' : 'HIGH', 'low' : 'LOW', 'close' : 'CLOSE', 'previousClose' : 'PREV_CLOSE', 
                                            'totalTrades' : 'CONTRACTS', 'totalTradesMCX' : 'CONTRACTS_MCX', 'tradedAmount' : 'VAL_INLAKH', 
                                            'openInterest' : 'OPEN_INT', 'tradeDate' : 'TIMESTAMP'})
                

            # if (df.Datetime.dt.date.isin(self.dates)).any():
            #         temp_df = df.loc[(df['Datetime'].dt.date.isin(self.dates))].copy()
            #         clean_df = df.loc[~(df['Datetime'].dt.date.isin(self.dates))].copy()
            #         if ceil or format_59:
            #             clean_df = clean_df.loc[(clean_df['Datetime'].dt.time >= pd.to_datetime('09:15:00').time()) &
            #                                     (clean_df['Datetime'].dt.time <= pd.to_datetime('15:30:00').time())].copy()
            #         else:
            #             clean_df = clean_df.loc[(clean_df['Datetime'].dt.time >= pd.to_datetime('09:15:00').time()) &
            #                                     (clean_df['Datetime'].dt.time <= pd.to_datetime('15:29:00').time())].copy()
                        
            #         df = pd.concat([clean_df, temp_df]).sort_values(by=['Datetime']).reset_index(drop=True)

            # else:
            #     if ceil or format_59:
            #         df = df.loc[(df['Datetime'].dt.time >= pd.to_datetime('09:15:00').time()) &
            #                                 (df['Datetime'].dt.time <= pd.to_datetime('15:30:00').time())].reset_index(drop=True)
            #     else:
            #         df = df.loc[(df['Datetime'].dt.time >= pd.to_datetime('09:15:00').time()) &
            #                                 (df['Datetime'].dt.time <= pd.to_datetime('15:29:00').time())].reset_index(drop=True)    
            if remove_special_dates:
                if (self.data_type == 'Bhavcopy'):
                    df = df.loc[~(df['TIMESTAMP'].dt.date.isin(self.special_dates))].copy()
                else:
                    df = df.loc[~(df['Datetime'].dt.date.isin(self.special_dates))].copy()

            if datetime_index:
                if (self.data_type == 'Bhavcopy'):
                    df.set_index('TIMESTAMP', inplace=True)
                    return df.sort_index()
                else:
                    df.set_index('Datetime', inplace=True)
                    return df.sort_index()
            if (self.data_type == 'Bhavcopy'):    
                return df.sort_values(by=['TIMESTAMP']).reset_index(drop=True)
            else:
                return df.sort_values(by=['Datetime']).reset_index(drop=True)
        else:
            if remove_special_dates:
                df = df.loc[~(df['tradeDate'].dt.date.isin(self.special_dates))].copy()

            if datetime_index:
                df.set_index('tradeDate', inplace=True)
                return df.sort_index()
            return df.sort_values(by=['tradeDate']).reset_index(drop=True)
    
class Performance_Profile(object):
    
    def __init__(self, column_name = 'pnl', date_col = 'Date',aggregate = True):
        self.column = column_name
        self.aggregate = aggregate
        self.date_col = date_col
        self.var_df_dd = pd.DataFrame()
        self.var_df = pd.DataFrame()
    
    def streak(self, DF, pl_col = None, date_col = None):
        df = DF.copy()
        if pl_col is None:
            pl_col = self.column
        if date_col is None:
            date_col = self.date_col

        try:
            df[date_col] = pd.to_datetime(df[date_col])
        except:
            pass
        
        if self.aggregate:
            df = df.groupby(date_col).agg({pl_col : 'sum'}).reset_index()
        
        conse_dict = {}
        
        df['PnL'] = np.where(df[pl_col] < 0, 'L', 'P')
        mask = df['PnL'] != df['PnL'].shift(1)
        df['Mask'] = mask.cumsum()
        # Assign group numbers to the rows
        group_numbers = mask.cumsum()
        # Perform cumulative sum within each group
        df['CumPL'] = df.groupby(group_numbers)[pl_col].cumsum()
        
        max_index = df['CumPL'].idxmax()
        min_index = df['CumPL'].idxmin()
        
        max_mask = df.iloc[max_index]['Mask']
        min_mask = df.iloc[min_index]['Mask']
        
        conse_dict['max_conse_profit_start'] = df.loc[df['Mask'] == max_mask].iloc[0][date_col]
        conse_dict['max_conse_profit_end'] = df.loc[df['Mask'] == max_mask].iloc[-1][date_col]
        
        conse_dict['max_conse_loss_start'] = df.loc[df['Mask'] == min_mask].iloc[0][date_col]
        conse_dict['max_conse_loss_end'] = df.loc[df['Mask'] == min_mask].iloc[-1][date_col]
        
        conse_dict['max_conse_profit'] = df['CumPL'].max()
        conse_dict['max_conse_loss'] = df['CumPL'].min()
        
        conse_dict['conse_loss_days'] = (conse_dict['max_conse_loss_end'] - conse_dict['max_conse_loss_start']).days
        conse_dict['conse_profit_days'] = (conse_dict['max_conse_profit_end'] - conse_dict['max_conse_profit_start']).days
        
        # conse_dict['conse_loss_days'] = len(df.loc[df['Date'].between(conse_dict['max_conse_loss_start'], conse_dict['max_conse_loss_end'])])
        # conse_dict['conse_profit_days'] = len(df.loc[df['Date'].between(conse_dict['max_conse_profit_start'], conse_dict['max_conse_profit_end'])])
        
        conse_df = pd.DataFrame(pd.Series(conse_dict))
        
        return conse_df.T
    



    def drawdown_df(self, DF, initial_amt = 10000, want_df = False):
        
        df = DF.copy()
        
        try:
            df['Date'] = pd.to_datetime(df['Date'])
        except:
            pass
        
        if self.aggregate:
            df = df.groupby('Date').agg({self.column : 'sum'}).reset_index()
        # for idx in range(len(df)):
        #     # break
        #     if idx == 0:
        #         df.loc[idx, 'Capital'] = df.loc[idx, 'pnl'] + initial_amt
                
        #     else:
        #         df.loc[idx, 'Capital'] = df.loc[idx-1, 'Capital'] + df.loc[idx, 'pnl']
        
        df['Capital'] = df[self.column].cumsum() + initial_amt

        z = [10000]
        for i in range(len(df)):

            z.append(df['Capital'].iloc[i])
            df.loc[i, 'DD TPL'] = df['Capital'].iloc[i]-max(z)  ### subtracting the current row capital with max of all capital
            if (df.loc[i, 'DD TPL'] > 0): ## IF answer is positive we keep drawdown 0
                df.loc[i, 'DD TPL'] = 0
                
            if (df.loc[i, 'DD TPL'] < 0): ## IF answer is negative ;drawdown will be the value obtained
                df.loc[i, 'DD TPL'] = df.loc[i, 'DD TPL']       

        # df['DD TPL'] = df['Capital'] - initial_amt
        # df.loc[df['DD TPL'] < 0, 'DD TPL'] = 0



        x = [] # start Date of Drawdown
        x1 = [] # Day before Date of Drawdown (Peak Value)
        y = [] # Exit Date of Drawdown
        z = [] # Min Value of Drawdown
        z1 = [] # Date Of min value of Drawdown

         ## TO Calculate Draw down range ##

        key = 0
        # closed_drawdown = False
        for i in range(len(df)):
            if (df['DD TPL'].iloc[i] < 0) and (key == 0):
                x.append(df['Date'].iloc[i])
                x1.append(df['Date'].iloc[i-1])
                key = 1
                a = i
                continue
                
            if (df['DD TPL'].iloc[i] >=0) and (key == 1):
                key =0
                y.append(df['Date'].iloc[i])
                z.append(df['DD TPL'].loc[a:i].min())
                q = df['DD TPL'].loc[a:i].idxmin()
                z1.append(df['Date'].iloc[q])
                a = 0
                # closed_drawdown = True
                
            if (key ==1) and (i == len(df)-1):
                del x[-1]
                del x1[-1]

        if len(x) > len(y):
            del x[-1]
            del x1[-1]
            
        drawdown = pd.DataFrame({'Start Date':x,'End Date':y,'Min Value':z,'Min Value Date':z1,'Peak Value Date':x1,},
                                 columns=['Start Date','End Date','Min Value','Min Value Date','Peak Value Date'])
        # return drawdown
        try:
            drawdown['No. of Days'] = (drawdown['End Date']- drawdown['Min Value Date'] ) //np.timedelta64(1, 'D')
        except:
            drawdown['No. of Days'] = (drawdown['End Date']- drawdown['Min Value Date'] ).dt.days
        drawdown = drawdown.sort_values(by=['Min Value'],ascending = True)
        drawdown = drawdown.reset_index(drop= True)
        drawdown = drawdown.loc[0:4] 
        
        

        peak_date = drawdown['Peak Value Date'].iloc[0]
        peak_value = df[df['Date'] == peak_date]['Capital'].values[0]
        #### For Trough value of Drawdown ####
        tr_date = drawdown['Min Value Date'].iloc[0]
        tr_value = df[df['Date'] == tr_date]['Capital'].values[0]

        ##### MDD Ratio ###
        mddr = (tr_value - peak_value) / peak_value
        #CAGR
        # factor = 1
        # n = len(df)/(252*factor)
        months = (df.iloc[-1]['Date'] - df.iloc[0]['Date']).days / (365.25 / 12)
        years = (df.iloc[-1]['Date'] - df.iloc[0]['Date']).days / 365.25
        cagr_month = ((df.iloc[-1]['Capital'] / initial_amt) ** (1 / months)) - 1
        cagr_year = ((df.iloc[-1]['Capital'] / initial_amt) ** (1 / years)) - 1
        # Return to MDD
        RTM = cagr_year/abs(mddr)
        
        MDD = pd.DataFrame({(peak_date, peak_value, tr_date, tr_value, mddr, cagr_month, cagr_year, RTM)}, 
                           columns=['Peak Date', 'Peak Value','Trough Date','Trough Value','MDD Ratio', 'CAGR_Monthly', 'CAGR_Yearly', 'Return to MDD'])
        
        if want_df:
            df['Capital_Pct'] = df['Capital'].pct_change()
            df.set_index('Date', inplace=True)
            return MDD, drawdown, df
        else:
            return MDD, drawdown

    def common_kpis(self, tradebook, margin, lot_size, pl_col = None, date_col = None, bars_added = False, want_dd = False):
        if pl_col is None:
            pl_col = self.column
        if date_col is None:
            date_col = self.date_col
        
        # kpis = {}
        
        # Calculate necessary columns
        tradebook['LOT_PL'] = tradebook[pl_col] * lot_size
        tradebook['ROI'] = (tradebook['LOT_PL'] / margin) * 100
        pl = tradebook[pl_col].sum()
        # Basic metrics
        total_trades = len(tradebook[pl_col])
        avg_profit_loss = tradebook[pl_col].mean()
        avg_profit_loss_pct = tradebook['ROI'].mean()

        # Winners metrics
        winners = (tradebook.loc[tradebook[pl_col] > 0][pl_col].count()) / total_trades
        total_profit = tradebook.loc[tradebook[pl_col] > 0][pl_col].sum()
        avg_profit = tradebook.loc[tradebook[pl_col] > 0][pl_col].mean()
        avg_profit_pct = tradebook.loc[tradebook[pl_col] > 0]['ROI'].mean()

        # Largest win metrics
        largest_win = tradebook.loc[tradebook[pl_col] > 0][pl_col].max()
        largest_win_pct = tradebook.loc[tradebook[pl_col] > 0]['ROI'].max()

        # Losers metrics
        losers = (tradebook.loc[tradebook[pl_col] < 0][pl_col].count()) / total_trades
        total_loss = tradebook.loc[tradebook[pl_col] < 0][pl_col].sum()
        avg_loss = tradebook.loc[tradebook[pl_col] < 0][pl_col].mean()
        avg_loss_pct = tradebook.loc[tradebook[pl_col] < 0]['ROI'].mean()

        # Largest loss metrics
        largest_loss = tradebook.loc[tradebook[pl_col] < 0][pl_col].min()
        largest_loss_pct = tradebook.loc[tradebook[pl_col] < 0]['ROI'].min()

        expectancy_ratio = ((avg_profit * winners) - (avg_loss * losers)) / 100


        # Streaks metrics
        streak_df = self.streak(tradebook)
        max_consecutive_profit = streak_df['max_conse_profit'].iloc[0]
        max_consecutive_profit_days = streak_df['conse_profit_days'].iloc[0]
        # max_consecutive_profit_start = streak_df['max_conse_profit_start'].iloc[0]
        # max_consecutive_profit_end = streak_df['max_conse_profit_end'].iloc[0]
        max_consecutive_loss = streak_df['max_conse_loss'].iloc[0]
        max_consecutive_loss_days = streak_df['conse_loss_days'].iloc[0]
        # max_consecutive_loss_start = streak_df['max_conse_loss_start'].iloc[0]
        # max_consecutive_loss_end = streak_df['max_conse_loss_end'].iloc[0]

        # Maximum drawdown metrics
        dd = pd.DataFrame()
        dd['Date'] = tradebook[date_col]
        # dd['ExitDate'] = tradebook[exit_date_col]
        dd['equity_curve'] = 1 + tradebook[pl_col].cumsum()
        dd['running_max'] = dd['equity_curve'].cummax()
        dd['drawdown'] = dd['equity_curve'] - dd['running_max']
        dd.reset_index(drop=True, inplace=True)
        # max_drawdown = dd['drawdown'].min()
        # max_drawdown_pct = max_drawdown / dd['running_max'].max() if dd['running_max'].max() != 0 else 0
        # Drawdown DataFrame
        drawdown_df = []
        drawdown_start, drawdown_low = None, None
        for i in range(len(dd)):
            if dd['drawdown'].iloc[i] < 0:
                if drawdown_start is None:
                    drawdown_start = dd['Date'].iloc[i]
                    peak_value = dd['running_max'].iloc[i]
                    low_value = dd['equity_curve'].iloc[i]
                    drawdown_low_date = dd['Date'].iloc[i]
                    drawdown_low = dd['drawdown'].iloc[i]
                if dd['equity_curve'].iloc[i] < low_value and drawdown_start is not None:
                    low_value = dd['equity_curve'].iloc[i]
                    drawdown_low_date = dd['Date'].iloc[i]
                    drawdown_low = dd['drawdown'].iloc[i]
                    
            elif dd['drawdown'].iloc[i] >= 0 and drawdown_start is not None:
                drawdown_end = dd['Date'].iloc[i]
                drawdown_df.append({
                    "StartDate": drawdown_start,
                    "PeakValue": peak_value,
                    "LowDate" : drawdown_low_date,
                    "LowValue": low_value,
                    "DrawdownLow": drawdown_low,
                    "EndDate": drawdown_end
                })
                drawdown_start, drawdown_low = None, None
        
        if len(drawdown_df) > 0:
            drawdown_df = pd.DataFrame(drawdown_df)
            # try:
            drawdown_df['Drawdown_Days'] = (drawdown_df['EndDate'] - drawdown_df['StartDate']) //np.timedelta64(1, 'D')
            drawdown_df['Recovery_Days'] = (drawdown_df['EndDate'] - drawdown_df['LowDate']) //np.timedelta64(1, 'D')
            # except:
            #     drawdown_df['Drawdown_Days'] = (drawdown_df['EndDate'] - drawdown_df['StartDate']).dt.days
            #     drawdown_df['Recovery_Days'] = (drawdown_df['EndDate'] - drawdown_df['LowDate']).dt.days

            drawdown_df['Recovery %'] = drawdown_df['Recovery_Days'] / drawdown_df['Drawdown_Days']
            drawdown_df['Drawdown %'] = drawdown_df['DrawdownLow'] / drawdown_df['PeakValue']

            drawdown_df = drawdown_df.sort_values(by=['DrawdownLow'],ascending = True)
            drawdown_df = drawdown_df.reset_index(drop= True)
            drawdown_df = drawdown_df.loc[0:15]
            max_drawdown = drawdown_df['DrawdownLow'].iloc[0]
            max_drawdown_pct = drawdown_df['Drawdown %'].iloc[0]
            mdd_days = drawdown_df['Drawdown_Days'].iloc[0]
            mdd_recovery = drawdown_df['Recovery_Days'].iloc[0]
            mdd_recovery_pct = drawdown_df['Recovery %'].iloc[0]
            avg_dd_days = drawdown_df['Drawdown_Days'].mean()
            avg_recovery_days = drawdown_df['Recovery_Days'].mean()
            avg_recovery_pct = drawdown_df['Recovery %'].mean()
        else:
            max_drawdown = None
            max_drawdown_pct = None
            mdd_days = None
            mdd_recovery = None
            mdd_recovery_pct = None
            avg_dd_days = None
            avg_recovery_days = None
            avg_recovery_pct = None
            drawdown_df = pd.DataFrame()

        # Recovery Factor
        recovery_factor = pl / abs(max_drawdown) if max_drawdown != 0 else 0

        # CAR/MaxDD
        equity_curve = (margin + tradebook['LOT_PL'].cumsum()).dropna()
        total_days = (tradebook[date_col].max() - tradebook[date_col].min()).days
        cagr = ((equity_curve.iloc[-1] / margin) ** (365.25 / total_days) - 1) if total_days > 0 else 0
        car_max_dd = cagr / abs(max_drawdown_pct) if max_drawdown_pct != 0 else float('inf')

        # Sharpe Ratio
        daily_returns = tradebook['LOT_PL'] / margin
        sharpe_ratio = daily_returns.mean() / daily_returns.std() * (252 ** 0.5) if daily_returns.std() != 0 else 0

        # Profit factor and payoff ratio
        profit_factor = total_profit / abs(total_loss) if total_loss != 0 else float('inf')
        payoff_ratio = avg_profit / abs(avg_loss) if avg_loss != 0 else float('inf')

        risk_reward_ratio = round(abs(avg_loss) / avg_profit, 4)
        risk_reward = f'1:{round(1/risk_reward_ratio, 2)}'

        kpis = {
            "Total Trades": total_trades,
            "Profit + Loss" : pl,
            "Avg Profit/Loss": avg_profit_loss,
            "Avg Profit/Loss %": avg_profit_loss_pct,
            "Winners %": winners * 100,
            "Total Profit": total_profit,
            "Avg Profit": avg_profit,
            "Avg Profit %": avg_profit_pct,
            "Largest Win": largest_win,
            "Largest Win %": largest_win_pct,
            "Losers %": losers * 100,
            "Total Loss": total_loss,
            "Avg Loss": avg_loss,
            "Avg Loss %": avg_loss_pct,
            "Largest Loss": largest_loss,
            "Largest Loss %": largest_loss_pct,
            "Max Consecutive Profit": max_consecutive_profit,
            "Max Consecutive Profit Days": max_consecutive_profit_days,
            "Max Consecutive Loss": max_consecutive_loss,
            "Max Consecutive Loss Days": max_consecutive_loss_days,
            "Max Drawdown": max_drawdown,
            "Max Drawdown %": max_drawdown_pct * 100,
            "MDD Days": mdd_days,
            "MDD Recovery": mdd_recovery,
            "MDD Recovery %": mdd_recovery_pct * 100,
            "Avg DD Days": avg_dd_days,
            "Avg Recovery Days": avg_recovery_days,
            "Avg Recovery %": avg_recovery_pct * 100,
            "Recovery Factor": recovery_factor,
            "CAR/MaxDD": car_max_dd,
            "Sharpe Ratio": sharpe_ratio,
            "Profit Factor": profit_factor,
            "Payoff Ratio": payoff_ratio, 
            "Expectancy": expectancy_ratio,
            "Risk Reward Ratio" : risk_reward_ratio, 
            "Risk Reward" : risk_reward
        }

        if bars_added:
            avg_bars_held = tradebook['Bars'].mean()
            max_bars_held = tradebook['Bars'].max()
            min_bars_held = tradebook['Bars'].min()
            bars_in_largest_win = tradebook.loc[tradebook[pl_col] == largest_win]['Bars'].values[0]
            bars_in_largest_loss = tradebook.loc[tradebook[pl_col] == largest_loss]['Bars'].values[0]
            kpis['Avg Bars Held'] = avg_bars_held
            kpis['Max Bars Held'] = max_bars_held
            kpis['Min Bars Held'] = min_bars_held
            kpis['Bars in Largest Win'] = bars_in_largest_win
            kpis['Bars in Largest Loss'] = bars_in_largest_loss

        kpi_df = pd.DataFrame(kpis, index=["KPIs"]).T

        if want_dd:
            return kpi_df, drawdown_df, dd
        else:
            return kpi_df, drawdown_df

    def points_gained_lost(self, tradebook, pl_col=None, date_col=None):
        if pl_col is None:
            pl_col = self.column
        if date_col is None:
            date_col = self.date_col
        
        tradebook = tradebook.copy()  
        
        try:
            tradebook[date_col] = pd.to_datetime(tradebook[date_col])
        except:
            pass
        
        if self.aggregate:
            tradebook = tradebook.groupby(date_col).agg({pl_col : 'sum'}).reset_index()
            
        profit = tradebook.loc[tradebook[pl_col] > 0][pl_col].sum()
        loss = tradebook.loc[tradebook[pl_col] < 0][pl_col].sum()
        
        total = profit + loss
        
        total_trades = len(tradebook[pl_col])
        
        point_per_trade = total / total_trades
        
        # total_days = tradebook['Date'].dt.date.nunique()
        # points_per_day = total / total_days
        
        profit_trades = tradebook.loc[tradebook[pl_col] > 0][pl_col].count()
        loss_trades = tradebook.loc[tradebook[pl_col] <= 0][pl_col].count()
        
        if profit_trades + loss_trades == len(tradebook[pl_col]): total_trades = profit_trades + loss_trades
        else : print("Something's wrong")
        
        profit_trades_percent = profit_trades / total_trades
        loss_trades_percent = loss_trades / total_trades
        
        avg_win = profit / profit_trades
        avg_loss = abs(loss / loss_trades)
        
        # expectancy ratio
        exp = ((avg_win * profit_trades_percent) - (avg_loss * loss_trades_percent)) / 100

        
        df = pd.DataFrame({
            'Profit' : profit,
            'Loss' : loss,
            'Total'  :total,
            'Point_Per_Trade' : point_per_trade,
            'total_Trades' : total_trades,
            'Profit_Trades' : profit_trades,
            'Profit_Trades_%' : profit_trades_percent,
            'Loss_Trades' : loss_trades,
            'Loss_Trades_%' : loss_trades_percent,
            'Avg Win' : avg_win, 
            'Avg Loss' : avg_loss,
            'Exp' : exp 
            }, index = [0])
        
        return df
    
    # def pivot_table(self, DF):
    #     df = DF.copy()

    #     if self.aggregate:
    #         df = df.groupby(self.date_col).agg({self.column : 'sum'}).reset_index()
    #     mdf = pd.pivot_table(df, values = self.column, index = pd.to_datetime(df[f'{self.date_col}']).dt.year, columns = pd.to_datetime(df[f'{self.date_col}']).dt.month, aggfunc = 'sum')

    #     mdf['Total'] = mdf.sum(axis=1)
    #     mdf.loc['Total'] = mdf.sum(axis=0)
    #     mdf = mdf.reset_index().rename(columns = {f'{self.date_col}' : 'Year'})
    #     return mdf
    
    
    def update_file(self, filepath, dfs, sheet_name = 'Evaluation', startrow = 0):
        # startrow = 2
        with pd.ExcelWriter(filepath, mode="a", engine="openpyxl", if_sheet_exists='overlay') as writer:
            for df in dfs:
                df.to_excel(writer,sheet_name=sheet_name, startrow=startrow)
                startrow += (df.shape[0] + 2)

    
    def format_and_print_table(self, pivot_table):
        formatted_data = []
    
        for idx, row in pivot_table.iterrows():
            formatted_row = []
            for col in pivot_table.columns:
                value = row[col]
                if pd.isna(value):
                    formatted_row.append("NaN")
                elif value < 0:
                    formatted_row.append(colored(f"{value:.2f}", "red"))
                elif value > 0:
                    formatted_row.append(colored(f"{value:.2f}", "green"))
                else:
                    formatted_row.append(f"{value:.2f}")
            formatted_data.append(formatted_row)
    
        headers = list(pivot_table.columns)
        index = list(pivot_table.index)
    
        print(tabulate(formatted_data, headers=headers, showindex=index, tablefmt="fancy_grid"))
    
    
    def pivot_table(self, ts, pl_col = None, date_col = None):
        if pl_col is None:
            pl_col = self.column
        if date_col is None:
            date_col = self.date_col
        if ts.index.name == date_col:
            ts = ts.reset_index()
        Pivot_pnl = ts.copy()        
        Pivot_pnl[date_col] = pd.to_datetime(Pivot_pnl[date_col])
        Pivot_pnl['Year'] = Pivot_pnl[date_col].dt.year
        Pivot_pnl['Month'] = Pivot_pnl[date_col].dt.month
        pivot_table = pd.pivot_table(Pivot_pnl, values=pl_col,index='Year', columns='Month', aggfunc='sum', margins=True, margins_name='Total')
        try:
            self.format_and_print_table(pivot_table)
            return pivot_table
        except Exception as e:
            return pivot_table

    def analyze(self, ts, pl_col = None, date_col = None, margin = 450000, lot_size = 75, filepath = None, sheet_name = None, bars_added = False, save_ts = False, ts_name = 'OPT', trade_shuffle_dd = False, confidence_level = 0.95, num_simulations = 10000, plot_var = False):
        if pl_col is None:
            pl_col = self.column
        if date_col is None:
            date_col = self.date_col
        ts = ts.copy()
        # pp = Performance_Profile(column_name=col1, date_col = date_col)
        ts['LOT_PL'] = ts[pl_col] * lot_size
        ts['ROI'] = (ts['LOT_PL'] / margin) * 100
        ts['ROI_PCT'] = (ts['LOT_PL'] / margin)
        if ts.index.name == date_col:
            ts = ts.reset_index()
        points = self.points_gained_lost(ts, date_col = date_col, pl_col=pl_col)
        pivot = self.pivot_table(ts, pl_col = pl_col, date_col = date_col)

        output_dict = {}

        output_dict[pl_col] = ts[pl_col].sum()
        output_dict['Accuracy_SPOT'] = points['Profit_Trades_%'].values[0]
        output_dict['Avg PL_SPOT'] = ts[pl_col].mean()
        output_dict['Avg_PL_Year_SPOT'] = ts[pl_col].sum()/14
        output_dict['Positive_years_PL_SPOT'] = (pivot['Total'] > 0).sum()
        output_dict['Negative_years_PL_SPOT'] = (pivot['Total'] < 0).sum()

        kpi_df, drawdown_df= self.common_kpis(ts, margin = margin, lot_size = lot_size, pl_col=pl_col, date_col  = date_col, bars_added = bars_added)
        var_df = self.calculate_risk_metrics_df(ts = ts, returns_column='ROI_PCT', confidence_level=confidence_level, num_simulations=num_simulations)

        if trade_shuffle_dd:
            result_df, stats_df = self.trade_shuffling_analysis(ts, returns_column='ROI_PCT', n_simulations=10000, confidence_level=confidence_level, num_simulations=num_simulations)
            if plot_var:
                self.plot_trade_shuffling_results(result_df, stats_df)

        else:
            stats_df = pd.DataFrame()
            result_df = pd.DataFrame()
            
        # print(drawdown_df)

        kpis = kpi_df['KPIs'].to_dict()

        self.kpi_df = kpi_df
        self.dd_df = drawdown_df
        self.pivot = pivot
        self.points = points
        self.var_df = var_df
        # self.analysis_results = analysis_results
        self.stats_df = stats_df
        self.result_df = result_df

        output_dict = output_dict | kpis
        if filepath is not None and sheet_name is not None:
            if save_ts:
                self.update_file(filepath=filepath, dfs = [ts], sheet_name=ts_name)
            self.update_file(filepath=filepath, dfs = [pivot, kpi_df, drawdown_df, var_df, stats_df], sheet_name=sheet_name)
        try:
            pivot.index = pivot['Year']
        except:
            pass
        for k, v in pivot['Total'].iloc[:-1].to_dict().items():
            output_dict[f'{k}'] = v
        return output_dict
    
    
    def hist_var_cvar(self, returns, confidence_level=0.99):
        var = np.percentile(returns, (1 - confidence_level) * 100)
        cvar = returns[returns <= var].mean()
        return var, cvar

    def parametric_var_cvar(self, returns, confidence_level=0.99):
        mean_return = np.mean(returns)
        std_return = np.std(returns)
        z_score = stats.norm.ppf(1 - confidence_level)
        parametric_var = (mean_return + z_score * std_return)
        z_density = stats.norm.pdf(z_score)
        parametric_cvar = -(mean_return + std_return * z_density / (1 - confidence_level))
        return parametric_var, parametric_cvar


    def mc_bootstrap_var_cvar(self, returns, confidence_level=0.99, num_simulations=100000):
        simulated_returns = np.random.choice(returns, size=(num_simulations), replace=True)
        var_monte_carlo = np.percentile(simulated_returns, (1 - confidence_level) * 100)
        cvar_monte_carlo = simulated_returns[simulated_returns <= var_monte_carlo].mean()
        return var_monte_carlo, cvar_monte_carlo


    def mc_kde_var_cvar(self, returns, confidence_level=0.99, num_simulations=1000000):
        kde = gaussian_kde(returns)  # Fit KDE to historical returns
        simulated_returns = kde.resample(num_simulations)[0]  # Generate synthetic returns from KDE
        var_kde = np.percentile(simulated_returns, (1 - confidence_level) * 100)
        cvar_kde = simulated_returns[simulated_returns <= var_kde].mean()
        return var_kde, cvar_kde
        # returns = returns.to_numpy().reshape(-1, 1).copy()
        # kde = KernelDensity(kernel="epanechnikov", bandwidth=0.1).fit(returns)
        # # Generate synthetic returns
        # # simulated_returns = kde.sample(num_simulations).flatten()
        # # Create a range of values to estimate density
        # x_grid = np.linspace(returns.min(), returns.max(), 1000).reshape(-1, 1)

        # # Get density estimates for these values
        # log_densities = kde.score_samples(x_grid)  # Log densities
        # densities = np.exp(log_densities)  # Convert log density to probability

        # # Normalize densities to form a valid probability distribution
        # probabilities = densities / densities.sum()

        # # Use inverse transform sampling to generate synthetic returns
        # simulated_returns = np.random.choice(x_grid.flatten(), size=num_simulations, p=probabilities)

        # # Compute Value at Risk (VaR)
        # var_kde = np.percentile(simulated_returns, (1 - confidence_level) * 100)

        # # Compute Conditional Value at Risk (CVaR)
        # cvar_kde = simulated_returns[simulated_returns <= var_kde].mean()

        # return var_kde, cvar_kde
    
    def mc_student_t_var_cvar(self, returns, confidence_level=0.99):
        d, loc, scale = stats.t.fit(returns)
        # var = stats.t.ppf(1 - confidence_level, d, loc, scale)
        # t_density_at_var = stats.t.pdf(var, d, loc, scale)
        # prob_below_var = stats.t.cdf(var, d, loc, scale)
        
        # # The formula accounts for the specific properties of Student-t distribution
        # # For df > 1, the formula is:
        # if d > 1:
        #     cvar = loc - scale * (t_density_at_var * (d + var**2) / ((d - 1) * prob_below_var))
        # else:
        #     # For df ≤ 1, the expected value doesn't exist, use simulation instead
        #     num_simulations = 100000
        #     simulated_returns = stats.t.rvs(d, loc, scale, size=num_simulations)
        #     tail_returns = simulated_returns[simulated_returns <= var]
        #     cvar = np.mean(tail_returns) if len(tail_returns) > 0 else var


        t_var = stats.t.ppf(1 - confidence_level, d, loc, scale)
        x = np.linspace(t_var, min(returns), 1000)  # Generate values from VaR to min return
        pdf_vals = stats.t.pdf(x, d, loc, scale)  # Compute PDF values
        t_cvar = (np.trapz(pdf_vals * x, x) / stats.t.cdf(t_var, d, loc, scale))
        return t_var, t_cvar
    
    def calculate_risk_metrics_df(self, ts, returns_column='ROI', confidence_level=0.95,num_simulations=1000000):
        returns = ts[returns_column].dropna()
        returns = returns.replace([np.inf, -np.inf], np.nan).dropna()
        cum_returns = (returns).cumsum() + 1
        rolling_max = np.maximum.accumulate(cum_returns)
        # drawdowns = (cum_returns - rolling_max) / rolling_max
        drawdowns = (cum_returns - rolling_max) / rolling_max


        squared_drawdowns = drawdowns ** 2

        ulcer_index = np.sqrt(np.mean(squared_drawdowns))
        
        var, cvar = self.hist_var_cvar(returns, confidence_level)
        parametric_var, parametric_cvar = self.parametric_var_cvar(returns, confidence_level)
        var_monte_carlo, cvar_monte_carlo = self.mc_bootstrap_var_cvar(returns, confidence_level, num_simulations)
        var_kde, cvar_kde = self.mc_kde_var_cvar(returns, confidence_level, num_simulations)
        # t_var, t_cvar = self.mc_student_t_var_cvar(returns, confidence_level)

        var_dd, cvardd = self.hist_var_cvar(drawdowns, confidence_level)
        parametric_var_dd, parametric_cvar_dd = self.parametric_var_cvar(drawdowns, confidence_level)
        var_monte_carlo_dd, cvar_monte_carlo_dd = self.mc_bootstrap_var_cvar(drawdowns, confidence_level, num_simulations)
        var_kde_dd, cvar_kde_dd = self.mc_kde_var_cvar(drawdowns, confidence_level, num_simulations)
        # t_var_dd, t_cvar_dd = self.mc_student_t_var_cvar(drawdowns, confidence_level)

        var_df = pd.DataFrame(index=pd.MultiIndex.from_tuples([], names=['Source', 'Index']))
        var_df.loc[(returns_column, 0), ['Approach', 'VaR', 'CVaR']] = ['Historical', var, cvar]
        var_df.loc[(returns_column, 1), ['Approach', 'VaR', 'CVaR']] = ['Parametric (Normality Assumed)', parametric_var, parametric_cvar]
        var_df.loc[(returns_column, 2), ['Approach', 'VaR', 'CVaR']] = ['MC Bootstrapped', var_monte_carlo, cvar_monte_carlo]
        var_df.loc[(returns_column, 3), ['Approach', 'VaR', 'CVaR']] = ['MC KDE (Non-Parametric)', var_kde, cvar_kde]

        var_df.loc[('DD', 0), ['Approach', 'VaR', 'CVaR']] = ['Historical', var_dd, cvardd]
        var_df.loc[('DD', 1), ['Approach', 'VaR', 'CVaR']] = ['Parametric (Normality Assumed)', parametric_var_dd, parametric_cvar_dd]
        var_df.loc[('DD', 2), ['Approach', 'VaR', 'CVaR']] = ['MC Bootstrapped', var_monte_carlo_dd, cvar_monte_carlo_dd]
        var_df.loc[('DD', 3), ['Approach', 'VaR', 'CVaR']] = ['MC KDE (Non-Parametric)', var_kde_dd, cvar_kde_dd]

        var_df['VaR'] = var_df['VaR'].apply(lambda x: f"{x*100:.4f}%")
        var_df['CVaR'] = var_df['CVaR'].apply(lambda x: f"{x*100:.4f}%")
        var_df['ULCER_INDEX'] = f"{ulcer_index*100:.4f}%"

        return var_df

    def calculate_risk_metrics(self, ts, returns_column='ROI', confidence_level=0.95,num_simulations=1000000):
        returns = ts[returns_column].dropna()
        returns = returns.replace([np.inf, -np.inf], np.nan).dropna()
        cum_returns = (returns).cumsum() + 1
        rolling_max = np.maximum.accumulate(cum_returns)
        # drawdowns = (cum_returns - rolling_max) / rolling_max
        drawdowns = (cum_returns - rolling_max)


        squared_drawdowns = drawdowns ** 2

        ulcer_index = np.sqrt(np.mean(squared_drawdowns))
        
        var, cvar = self.hist_var_cvar(returns, confidence_level)
        parametric_var, parametric_cvar = self.parametric_var_cvar(returns, confidence_level)
        var_monte_carlo, cvar_monte_carlo = self.mc_bootstrap_var_cvar(returns, confidence_level, num_simulations)
        var_kde, cvar_kde = self.mc_kde_var_cvar(returns, confidence_level, num_simulations)
        # t_var, t_cvar = self.mc_student_t_var_cvar(returns, confidence_level)

        var_dd, cvardd = self.hist_var_cvar(drawdowns, confidence_level)
        parametric_var_dd, parametric_cvar_dd = self.parametric_var_cvar(drawdowns, confidence_level)
        var_monte_carlo_dd, cvar_monte_carlo_dd = self.mc_bootstrap_var_cvar(drawdowns, confidence_level, num_simulations)
        var_kde_dd, cvar_kde_dd = self.mc_kde_var_cvar(drawdowns, confidence_level, num_simulations)
        # t_var_dd, t_cvar_dd = self.mc_student_t_var_cvar(drawdowns, confidence_level)

        # return ulcer_index, var_df, var_df_dd

        return {
            'ulcer_index': ulcer_index,
            'historical_var': var,
            'historical_cvar': cvar,
            'parametric_var': parametric_var,
            'parametric_cvar': parametric_cvar,
            'mc_bootstrap_var': var_monte_carlo,
            'mc_bootstrap_cvar': cvar_monte_carlo,
            'mc_kde_var': var_kde,
            'mc_kde_cvar': cvar_kde,
            # 'student_t_var': t_var,
            # 'student_t_cvar': t_cvar,
            'historical_var_dd': var_dd,
            'historical_cvar_dd': cvardd,
            'parametric_var_dd': parametric_var_dd,
            'parametric_cvar_dd': parametric_cvar_dd,
            'mc_bootstrap_var_dd': var_monte_carlo_dd,
            'mc_bootstrap_cvar_dd': cvar_monte_carlo_dd,
            'mc_kde_var_dd': var_kde_dd,
            'mc_kde_cvar_dd': cvar_kde_dd,
            # 'student_t_var_dd': t_var_dd,
            # 'student_t_cvar_dd': t_cvar_dd,
            'confidence_level': confidence_level,
        }
    

        
    def calculate_drawdowns(self, returns):
        cum_returns = (returns).cumsum() + 1
        rolling_max = np.maximum.accumulate(cum_returns)
        # drawdowns = (cum_returns - rolling_max) / rolling_max
        drawdowns = (cum_returns - rolling_max)
        return drawdowns, drawdowns.min()

    def trade_shuffling_analysis(self, ts, returns_column='ROI', n_simulations=10000, confidence_level=0.95, num_simulations=100000):
        original_returns = ts[returns_column].dropna().values
        original_drawdowns, original_max_dd = self.calculate_drawdowns(original_returns)
        original_metrics = self.calculate_risk_metrics(ts, returns_column, confidence_level=confidence_level, num_simulations=num_simulations)
        original_metrics['MDD'] = original_max_dd

        def do_process(i, original_returns):
            shuffled_returns = np.random.permutation(original_returns)
            _, max_dd = self.calculate_drawdowns(shuffled_returns)
            # simulated_max_dds.append(max_dd)
            temp_df = pd.DataFrame({returns_column: shuffled_returns})
            risk_metrics = self.calculate_risk_metrics(temp_df, returns_column, confidence_level=confidence_level, num_simulations=num_simulations)
            risk_metrics['MDD'] = max_dd
            return risk_metrics
        
        # result = jb.Parallel(n_jobs=-1, verbose=10)(
        #     jb.delayed(do_process)(i, original_returns) for i in tqdm(range(n_simulations), desc="Running simulations")
        # )

        result = jb.Parallel(n_jobs=-1, verbose=10)(
            jb.delayed(do_process)(i, original_returns) for i in range(n_simulations)
        )

        lower_percentile = (1 - confidence_level) / 2 * 100
        upper_percentile = (1 + confidence_level) / 2 * 100
        result_df = pd.DataFrame(result)
        # self.result_df = result_df

        # # Calculate statistics
        # simulated_max_dds = result_df['MDD'].values
        # max_dd_stats = {
        #     'original': original_max_dd,
        #     'mean': np.mean(simulated_max_dds),
        #     'median': np.median(simulated_max_dds),
        #     'min': np.min(simulated_max_dds),
        #     'max': np.max(simulated_max_dds),
        #     'lower_bound': np.percentile(simulated_max_dds, lower_percentile),
        #     'upper_bound': np.percentile(simulated_max_dds, upper_percentile),
        #     'percentile_rank': stats.percentileofscore(simulated_max_dds, original_max_dd)
        # }
        
        # simulated_ulcer_indices = result_df['ulcer_index'].values
        # ulcer_index_stats = {
        #     'original': original_metrics['ulcer_index'],
        #     'mean': np.mean(simulated_ulcer_indices),
        #     'median': np.median(simulated_ulcer_indices),
        #     'min': np.min(simulated_ulcer_indices),
        #     'max': np.max(simulated_ulcer_indices),
        #     'lower_bound': np.percentile(simulated_ulcer_indices, lower_percentile),
        #     'upper_bound': np.percentile(simulated_ulcer_indices, upper_percentile),
        #     'percentile_rank': stats.percentileofscore(simulated_ulcer_indices, original_metrics['ulcer_index'])
        # }
        
        # simulated_vars = result_df['historical_var'].values
        # var_stats = {
        #     'original': original_metrics['historical_var'],
        #     'mean': np.mean(simulated_vars),
        #     'median': np.median(simulated_vars),
        #     'min': np.min(simulated_vars),
        #     'max': np.max(simulated_vars),
        #     'lower_bound': np.percentile(simulated_vars, lower_percentile),
        #     'upper_bound': np.percentile(simulated_vars, upper_percentile),
        #     'percentile_rank': stats.percentileofscore(simulated_vars, original_metrics['historical_var'])
        # }
        
        # simulated_cvars = result_df['historical_cvar'].values
        # cvar_stats = {
        #     'original': original_metrics['historical_cvar'],
        #     'mean': np.mean(simulated_cvars),
        #     'median': np.median(simulated_cvars),
        #     'min': np.min(simulated_cvars),
        #     'max': np.max(simulated_cvars),
        #     'lower_bound': np.percentile(simulated_cvars, lower_percentile),
        #     'upper_bound': np.percentile(simulated_cvars, upper_percentile),
        #     'percentile_rank': stats.percentileofscore(simulated_cvars, original_metrics['historical_cvar'])
        # }

        # simulated_kde_vars = result_df['mc_kde_var'].values
        # kde_var_stats = {
        #     'original': original_metrics['mc_kde_var'],
        #     'mean': np.mean(simulated_kde_vars),
        #     'median': np.median(simulated_kde_vars),
        #     'min': np.min(simulated_kde_vars),
        #     'max': np.max(simulated_kde_vars),
        #     'lower_bound': np.percentile(simulated_kde_vars, lower_percentile),
        #     'upper_bound': np.percentile(simulated_kde_vars, upper_percentile),
        #     'percentile_rank': stats.percentileofscore(simulated_kde_vars, original_metrics['mc_kde_var'])
        # }
        
        # simulated_kde_cvars = result_df['mc_kde_cvar'].values
        # kde_cvar_stats = {
        #     'original': original_metrics['mc_kde_cvar'],
        #     'mean': np.mean(simulated_kde_cvars),
        #     'median': np.median(simulated_kde_cvars),
        #     'min': np.min(simulated_kde_cvars),
        #     'max': np.max(simulated_kde_cvars),
        #     'lower_bound': np.percentile(simulated_kde_cvars, lower_percentile),
        #     'upper_bound': np.percentile(simulated_kde_cvars, upper_percentile),
        #     'percentile_rank': stats.percentileofscore(simulated_kde_cvars, original_metrics['mc_kde_cvar'])
        # }

        # stats_df = pd.DataFrame([max_dd_stats, ulcer_index_stats, var_stats, cvar_stats, kde_var_stats, kde_cvar_stats], index = ['MDD', 'ULCER_INDEX', 'VaR', 'CVaR', 'KDE_VaR', 'KDE_CVaR'])
        # stats_df['original'] = stats_df['original'].apply(lambda x: float(f"{x*100:.4f}"))
        # stats_df['mean'] = stats_df['mean'].apply(lambda x: float(f"{x*100:.4f}"))
        # stats_df['median'] = stats_df['median'].apply(lambda x: float(f"{x*100:.4f}"))
        # stats_df['min'] = stats_df['min'].apply(lambda x: float(f"{x*100:.4f}"))
        # stats_df['max'] = stats_df['max'].apply(lambda x: float(f"{x*100:.4f}"))
        # stats_df['lower_bound'] = stats_df['lower_bound'].apply(lambda x: float(f"{x*100:.4f}"))
        # stats_df['upper_bound'] = stats_df['upper_bound'].apply(lambda x: float(f"{x*100:.4f}"))

        stats_df = result_df.describe()
        stats_df.drop('count', axis=0, inplace=True)
        stats_df.drop('confidence_level', axis=1, inplace=True)
        for c in stats_df.columns:
            # break
            stats_df[c] = stats_df[c].apply(lambda x: float(f"{x*100:.4f}"))
            stats_df.loc['original', c] = float(f"{original_metrics[c]*100:.4f}")
            stats_df.loc['percentile_rank', c] = stats.percentileofscore(result_df[c], original_metrics[c])
            stats_df.loc['lower_bound', c] = float(f"{np.percentile(result_df[c], lower_percentile)*100:.4f}")
            stats_df.loc['upper_bound', c] = float(f"{np.percentile(result_df[c], upper_percentile)*100:.4f}")
        stats_df = stats_df.T
        
        # # All simulated data for potential plotting
        # simulated_data = {
        #     'max_drawdowns': simulated_max_dds,
        #     'ulcer_indices': simulated_ulcer_indices,
        #     'vars': simulated_vars,
        #     'cvars': simulated_cvars, 
        #     'kde_vars': simulated_kde_vars, 
        #     'kde_cvars': simulated_kde_cvars
        # }
        
        # return {
        #     'max_drawdown_stats': max_dd_stats,
        #     'ulcer_index_stats': ulcer_index_stats,
        #     'var_stats': var_stats,
        #     'cvar_stats': cvar_stats,
        #     'kde_var_stats': kde_var_stats,
        #     'kde_cvar_stats': kde_cvar_stats,
        #     'simulation_data': simulated_data,
        #     'n_simulations': n_simulations,
        #     'confidence_interval': confidence_level
        # }, stats_df

        return result_df, stats_df

    def plot_trade_shuffling_results(self, result_df, stats_df, confidance_level = 0.95):

        fig, axs = plt.subplots(5, 2, figsize=(20, 25))
        fig.suptitle('Trade Shuffling Analysis Results', fontsize=16)

        stats_df = stats_df.copy()
        try:
            stats_df.drop(['historical_var', 'historical_cvar', 'parametric_var', 'parametric_cvar', 'historical_var_dd', 'historical_cvar_dd', 'parametric_var_dd', 'parametric_cvar_dd'], axis=0, inplace=True)
        except:
            pass

        metrics = [
            ('MDD', 'Max Drawdown', 'MDD'),
            ('ulcer_index', 'Ulcer Index', 'ulcer_index'),
            ('mc_kde_var', 'Value at Risk KDE (VaR)', 'mc_kde_var'),
            ('mc_kde_cvar', 'Conditional VaR KDE (CVaR)', 'mc_kde_cvar'),
            ('mc_bootstrap_var', 'Value at Risk Bootstrapped (VaR)', 'mc_bootstrap_var'),
            ('mc_bootstrap_cvar', 'Conditional VaR Bootstrapped (CVaR)', 'mc_bootstrap_cvar'), 
            ('mc_bootstrap_var_dd', 'Max Drawdown Bootstrapped (VaR)', 'mc_bootstrap_var_dd'),
            ('mc_bootstrap_cvar_dd', 'Max Drawdown Bootstrapped (CVaR)', 'mc_bootstrap_cvar_dd'),
            ('mc_kde_var_dd', 'Max Drawdown KDE (VaR)', 'mc_kde_var_dd'),
            ('mc_kde_cvar_dd', 'Max Drawdown KDE (CVaR)', 'mc_kde_cvar_dd')
            # ('vars', 'Value at Risk (VaR)', 'var_stats'),
            # ('cvars', 'Conditional VaR (CVaR)', 'cvar_stats')
        ]
        
        for i, (data_key, title, stats_key) in enumerate(metrics):
            # break
            row, col = i // 2, i % 2
            ax = axs[row, col]
            
            # Get the data and stats
            # data = analysis_results['simulation_data'][data_key]
            # stats = analysis_results[stats_key]

            data = result_df[data_key].values * 100
            stats = stats_df.loc[stats_key].to_dict()
            
            # Plot histogram
            sns.histplot(data, kde=True, ax=ax)


            # # Add vertical lines for statistics
            # ax.axvline(stats['original'], color='r', linestyle='-', label=f'Original: {stats["original"]:.4f}')
            # ax.axvline(stats['mean'], color='g', linestyle='-', label=f'Mean: {stats["mean"]:.4f}')
            # ax.axvline(stats['lower_bound'], color='b', linestyle='--', 
            #         label=f'{int(analysis_results["confidence_interval"]*100)}% CI Lower: {stats["lower_bound"]:.4f}')
            # ax.axvline(stats['upper_bound'], color='b', linestyle='--', 
            #         label=f'{int(analysis_results["confidence_interval"]*100)}% CI Upper: {stats["upper_bound"]:.4f}')
            
            # # Set title and labels
            # ax.set_title(title)
            # ax.set_xlabel(title)
            # ax.set_ylabel('Frequency')
            # ax.legend()
            
            # Add vertical lines for statistics
            ax.axvline(stats['original'], color='r', linestyle='-', label=f'Original: {stats["original"]:.4f}%')
            ax.axvline(stats['mean'], color='g', linestyle='-', label=f'Mean: {stats["mean"]:.4f}%')

            # ax.axvline(stats['std'], color='r', linestyle='dashed', 
            #         label=f'STD: {stats["std"]:.4f}%')
            ax.axvline(stats['25%'], color='yellow', linestyle='--', 
                    label=f'25%: {stats["25%"]:.4f}%')
            ax.axvline(stats['50%'], color='black', linestyle='--', 
                    label=f'50%: {stats["50%"]:.4f}%')
            ax.axvline(stats['75%'], color='orange', linestyle='--', 
                    label=f'75%: {stats["75%"]:.4f}%')
            
            ax.axvline(stats['lower_bound'], color='blue', linestyle='--', 
                    label=f'{int(confidance_level*100)}% CI Lower: {stats["lower_bound"]:.4f}%')
            ax.axvline(stats['upper_bound'], color='blue', linestyle='--', 
                    label=f'{int(confidance_level*100)}% CI Upper: {stats["upper_bound"]:.4f}%')
            
            # Set title and labels
            ax.set_title(title)
            ax.set_xlabel(title)
            ax.set_ylabel('Frequency')
            ax.legend()
        
        plt.tight_layout(rect=[0, 0, 1, 0.96])
        return fig

# class QuantStats(Performance_Profile):

#     def __init__(self, ts, initial_amt = 10000, column_name = 'PL', aggregate = True):
#         self.df = ts.copy()
#         self.initial_amt = initial_amt 
#         self.column = column_name
#         self.aggregate = aggregate
        
#         try:
#             self.df['Date'] = pd.to_datetime(pd.to_datetime(self.df['EntryDate']).dt.date)
#         except:
#             pass
        
#         if self.aggregate:
#             self.df = self.df.groupby('Date').agg({self.column : 'sum'}).reset_index()
#         # self.mdd, self.drawdown, self.df = self.drawdown_df(self.ts, want_df=True)
#         self.df['Capital'] = self.df[self.column].cumsum() + initial_amt
#         self.df['Capital_Pct'] = self.df['Capital'].pct_change()
#         self.df.set_index('Date', inplace=True)
#         qs.reports.html(returns=self.df['Capital_Pct'], mode = 'full', output = 'tradereport.html')

#         pp = Performance_Profile(column_name='pnl', aggregate=True)
#         points = pp.points_gained_lost(self.df.reset_index())
#         mdd, drawdown, dfd = pp.drawdown_df(self.df.reset_index(), want_df=True)
#         streak = pp.streak(self.df.reset_index())
#         pivot = pp.pivot_table(self.df.reset_index())
        
#         pp.update_file('tradebook.xlsx', dfs = [pivot, points, streak, mdd, drawdown], sheet_name = 'Summary')


class Indicators():
    
    def __init__(self, src_name = 'Close') -> None:
        self.src_name = src_name
        
    def __create_source(self, df):
        
        if self.src_name == 'HLC3':
            df['HLC3'] = (df['High'] + df['Low'] + df['Close']) / 3
            
        elif self.src_name == 'OHLC4':
            df['OHLC4'] = (df['Open'] + df['High'] + df['Low'] + df['Close']) / 4
        
        elif self.src_name == 'HL2':
            df['HL2'] = (df['High'] + df['Low']) / 2
        
        elif self.src_name == 'HLCC4':
            df['HLCC4'] = (df['High'] + df['Low'] + df['Close'] + df['Close']) / 4
        
        elif self.src_name == 'HLC4':
            df['HLC4'] = (df['High'] + df['Low'] + df['Close'] + df['Volume']) / 4
        elif self.src_name == 'OHLCV':
            df['OHLCV'] = (df['Open'] + df['High'] + df['Low'] + df['Close'] + df['Volume']) / 5
        elif self.src_name == 'HLCV':
            df['HLCV'] = (df['High'] + df['Low'] + df['Close'] + df['Volume']) / 4
        elif self.src_name == 'OHLC':
            df['OHLC'] = (df['Open'] + df['High'] + df['Low'] + df['Close']) / 4
            
        return df

    def atr(self, DF, period=14, indc_num = 0):
        df = DF.copy()
        
        df[f'ATR_{indc_num}'] = ta.ATR(df['High'], df['Low'], df['Close'], timeperiod=period)
        return df
    
    
    def macd(self, DF, fastperiod=12, slowperiod=26, signalperiod=9,indc_num = 0):
        df = DF.copy()
        df[f'MACD_{indc_num}'], df[f'MACD_Signal_{indc_num}'], df[f'MACD_Hist_{indc_num}'] = ta.MACD(df['Close'], fastperiod=fastperiod, 
                                                                 slowperiod=slowperiod, 
                                                                 signalperiod=signalperiod
                                                                 )
        return df
    
    def bollinger_bands(self, DF, src_name='Close', period=14, nbdevup=2, nbdevdn=2, matype=0,indc_num = 0):
        df = DF.copy()
        
        if src_name not in ['Open', 'High', 'Low', 'Close', 'Volume']:
            self.src_name = src_name
            df = self.__create_source(df)

        
        df[f'Upper_Band_{indc_num}'], df[f'Middle_Band_{indc_num}'], df[f'Lower_Band_{indc_num}'] = ta.BBANDS(df[src_name], 
                                                                          timeperiod=period, 
                                                                          nbdevup=nbdevup, 
                                                                          nbdevdn=nbdevdn, 
                                                                          matype=matype
                                                                          )
        df[f'BB_Width_{indc_num}'] = df[f'Upper_Band_{indc_num}'] - df[f'Low_Band_{indc_num}']
        return df
        
    
    def ema(self, df, src_name = 'Close', period=14, indc_num = 0):
        if src_name not in ['Open', 'High', 'Low', 'Close', 'Volume']:
            self.src_name = src_name
            df = self.__create_source(df)

        df[f'EMA_{indc_num}'] = ta.EMA(df[src_name], timeperiod=period)
        return df
    
    def sma(self, df, src_name = 'Close', period=14, indc_num = 0):
        if src_name not in ['Open', 'High', 'Low', 'Close', 'Volume']:
            self.src_name = src_name
            df = self.__create_source(df)

        df[f'SMA_{indc_num}'] = ta.SMA(df[src_name], timeperiod=period)
        return df
    
    def rsi(self, DF, src_name = 'Close', period=14, indc_num = 0):
        df = DF.copy()
        if src_name not in ['Open', 'High', 'Low', 'Close', 'Volume']:
            self.src_name = src_name
            df = self.__create_source(df)

        df[f'RSI_{indc_num}'] = ta.RSI(df[src_name], timeperiod=period)
        
        return df
    
    def adx(self, DF, period=14, indc_num = 0):
        df = DF.copy()
        df[f'ADX_{indc_num}'] = ta.ADX(df['High'], df['Low'], df['Close'], timeperiod=period)
        return df

    
    def obv(self, DF, indc_num = 0):
        df = DF.copy()
        df[f'OBV_{indc_num}'] = ta.OBV(df['Close'], df['Volume'])
        return df

    def stochastic(self, DF, fastk_period=5, slowk_period=3, slowk_matype=0, slowd_period=3, slowd_matype=0, indc_num = 0):
        df = DF.copy()
        df[f'slowk_{indc_num}'], df[f'slowd_{indc_num}'] = ta.STOCH(df['High'], df['Low'], df['Close'], 
                                            fastk_period=fastk_period, 
                                            slowk_period=slowk_period, 
                                            slowk_matype=slowk_matype, 
                                            slowd_period=slowd_period, 
                                            slowd_matype=slowd_matype
                                            )
        return df
        
    
    def supertrend(df, period=10, multiplier=3): #final version
        """
        Returns the DataFrame augmented with:
        - 'ATR'
        - 'BasicUpperBand', 'BasicLowerBand'
        - 'FinalUpperBand', 'FinalLowerBand'
        - 'in_uptrend' (bool)
        - 'Supertrend' (the actual plotted band)
        """
        df = df.copy()
        
        # 1. True Range
        df['TR'] = pd.concat([
            df['High'] - df['Low'],
            (df['High'] - df['Close'].shift()).abs(),
            (df['Low']  - df['Close'].shift()).abs()
        ], axis=1).max(axis=1)
        
        # 2. Wilder's ATR (NaN for first period−1 bars)
        df['ATR'] = df['TR'].ewm(alpha=1/period, adjust=False, min_periods=period).mean()
        
        # 3. Basic Bands
        hl2 = (df['High'] + df['Low']) / 2
        df['BasicUpperBand'] = hl2 + multiplier * df['ATR']
        df['BasicLowerBand'] = hl2 - multiplier * df['ATR']
        
        # 4. Prepare Final Bands
        df['FinalUpperBand'] = np.nan
        df['FinalLowerBand'] = np.nan
        
        # 4a. Find the first index where ATR is non-NaN
        start_idx = df['ATR'].first_valid_index()
        if start_idx is None:
            # Not enough data to compute ATR at all
            return df
        
        # 4b. Initialize at that index
        df.loc[start_idx, 'FinalUpperBand'] = df.loc[start_idx, 'BasicUpperBand']
        df.loc[start_idx, 'FinalLowerBand'] = df.loc[start_idx, 'BasicLowerBand']
        
        # 4c. Iterate forward by label
        idxs = df.index.tolist()
        start_pos = idxs.index(start_idx)
        for idx in idxs[start_pos+1:]:
            prev = idxs[idxs.index(idx)-1]
            
            prev_fub = df.loc[prev, 'FinalUpperBand']
            prev_flb = df.loc[prev, 'FinalLowerBand']
            curr_bub = df.loc[idx,  'BasicUpperBand']
            curr_blb = df.loc[idx,  'BasicLowerBand']
            prev_close = df.loc[prev, 'Close']
            
            # UpperBand rule
            if (curr_bub < prev_fub) or (prev_close > prev_fub):
                df.loc[idx, 'FinalUpperBand'] = curr_bub
            else:
                df.loc[idx, 'FinalUpperBand'] = prev_fub
            
            # LowerBand rule
            if (curr_blb > prev_flb) or (prev_close < prev_flb):
                df.loc[idx, 'FinalLowerBand'] = curr_blb
            else:
                df.loc[idx, 'FinalLowerBand'] = prev_flb
        
        # 5. Trend & SuperTrend line
        df['in_uptrend'] = True
        df['Supertrend'] = np.nan
        
        for idx in idxs[start_pos+1:]:
            prev = idxs[idxs.index(idx)-1]
            prev_fub = df.loc[prev, 'FinalUpperBand']
            prev_flb = df.loc[prev, 'FinalLowerBand']
            curr_close = df.loc[idx, 'Close']
            
            # Determine trend
            if curr_close > prev_fub:
                up = True
            elif curr_close < prev_flb:
                up = False
            else:
                up = df.loc[prev, 'in_uptrend']
            
            df.loc[idx, 'in_uptrend'] = up
            # Supertrend plots the opposite band
            df.loc[idx, 'Supertrend'] = (
                df.loc[idx, 'FinalLowerBand'] if up else df.loc[idx, 'FinalUpperBand']
            )
        
        return df['Supertrend']
        
        # return df
    
    def vwap(self, DF):
        
        df = DF.copy()
        
        try:
            df['Datetime'] = pd.to_datetime(df['Datetime'])
        except:
            pass
        
        def operations(group):
            hlc3 = (group['High'] + group['Low'] + group['Close']) / 3
            
            cumvol = group['Volume'].cumsum()
            
            cumvolprice = (hlc3 * group['Volume']).cumsum()
            
            group['VWAP'] = cumvolprice / cumvol
            
            return group['VWAP']
        
        df = DF.copy()
        
        group = df.groupby(df['Datetime'].dt.date)
        df[f'VWAP'] = group.apply(operations).values

        return df

    def heiken_ashi(self, DF):  # Needs to be modified
        df = DF.copy()
        
        # df.reset_index(drop=True, inplace=True)
        
        df['Close'] = (df['Open'] + df['High'] + df['Low'] + df['Close']) / 4
        # df.loc[0, 'Open'] = (df['Open'][0] + df['Close'][0]) / 2
        
        # for i in range(1, len(df)):
        #     df.at[i, 'Open'] = (df.at[i - 1, 'Open'] + df.at[i - 1, 'Close']) / 2
        
        open_arr = df['Open'].values
        close_arr = df['Close'].values

        # # Initialize the first element of the 'Open' array
        # open_arr[0] = (open_arr[0] + close_arr[0]) / 2

        # # Iterate over the remaining rows using iterrows
        # for i in range(len(open_arr)):
        #     if i == 0:
        #         continue
        #     open_arr[i] = (open_arr[i-1] + close_arr[i-1]) / 2

        # # Update the 'Open' column in the DataFrame
        # df['Open'] = open_arr
        
        # df.loc[1:, 'Open'] = (df['Open'].shift(1) + df['Close'].shift(1)) / 2
        
        # @njit
        def update_open(open_arr, close_arr):
            # Initialize the first element of the 'Open' array
            open_arr[0] = (open_arr[0] + close_arr[0]) / 2

            # Iterate over the remaining rows
            for i in range(1, len(open_arr)):
                open_arr[i] = (open_arr[i-1] + close_arr[i-1]) / 2

            return open_arr
        
        open_arr = update_open(open_arr, close_arr)
        df['Open'] = open_arr
        
        df['High'] = df[['High', 'Close', 'Open']].max(axis=1)
        df['Low'] = df[['Low', 'Open', 'Close']].min(axis=1)
        

        # df['ha_close'] = (df['Open'] + df['High'] + df['Low'] + df['Close']) / 4
        
        # # Calculate Heikin-Ashi Open (first bar is (Open + Close) / 2)
        # df['ha_open'] = (df['Open'] + df['Close']) / 2
        
        # for i in range(1, len(df)):
        #     df.at[i, 'ha_open'] = (df.at[i - 1, 'ha_open'] + df.at[i - 1, 'ha_close']) / 2
        
        # # Calculate Heikin-Ashi High and Low
        # df['ha_high'] = df[['High', 'ha_open', 'ha_close']].max(axis=1)
        # df['ha_low'] = df[['Low', 'ha_open', 'ha_close']].min(axis=1)
        
        return df
    
    def know_sure_thing(self, prices, roclen1=10, roclen2=15, roclen3=20, roclen4=30, 
					 smalen1=10, smalen2=10, smalen3=10, smalen4=15, siglen=9):

        roc1 = ta.ROC(prices, timeperiod=roclen1)
        roc2 = ta.ROC(prices, timeperiod=roclen2)
        roc3 = ta.ROC(prices, timeperiod=roclen3)
        roc4 = ta.ROC(prices, timeperiod=roclen4)

        # Apply Simple Moving Averages (SMA) to smooth the ROC values
        smoothed_roc1 = ta.SMA(roc1, timeperiod=smalen1)
        smoothed_roc2 = ta.SMA(roc2, timeperiod=smalen2)
        smoothed_roc3 = ta.SMA(roc3, timeperiod=smalen3)
        smoothed_roc4 = ta.SMA(roc4, timeperiod=smalen4)

        # Compute the final KST indicator
        kst = smoothed_roc1 + 2 * smoothed_roc2 + 3 * smoothed_roc3 + 4 * smoothed_roc4

        # Compute the Signal Line (SMA of KST)
        signal = ta.SMA(kst, timeperiod=siglen)

        return kst, signal
    
    def momentum(self, DF, timeperiod, src_name = 'Close', indc_num = 0):
        df = DF.copy()
        if src_name not in ['Open', 'High', 'Low', 'Close', 'Volume']:
            self.src_name = src_name
            df = self.__create_source(df)
        df[f'MOMENTUM_{indc_num}'] = ta.MOM(df[src_name], timeperiod=timeperiod)
        return df

    def stochastic_rsi(self, DF, timeperiod, fastk_period, fastd_period, fastd_matype, indc_num = 0):
        df = DF.copy()
        df[f'stochrsi_fastk_{indc_num}'], df[f'stochrsi_fastd_{indc_num}'] = ta.STOCHRSI(df['Close'], timeperiod=timeperiod, 
                                                                 fastk_period=fastk_period, 
                                                                 fastd_period=fastd_period, 
                                                                 fastd_matype=fastd_matype)        
        return df
    
    
    def accumulation_distribution(self, DF):
        df = DF.copy()
        
        open = df['Open']
        close = df['Close']
        high = df['High']
        low = df['Low']
        volume = df['Volume']
        
        cum_vol = np.cumsum(volume)
        if cum_vol[-1] == 0:
            raise ValueError("No volume is provided by the data vendor.")

        ad = np.where((close == high) & (close == low) | (high == low), 0, ((2 * close - low - high) / (high - low)) * volume)
        df['ADL'] = np.cumsum(ad)
        return df


    

    def ichimoku_cloud(self, DF, conversion_periods=9, base_periods=26, lagging_span2_periods=52, indc_num = 0):
        
        df = DF.copy()
        
        low_prices = df['Low']
        high_prices = df['High']
        # close_prices =  df['Close']
        
        
        def donchian(low_prices, high_prices, length):
            lowest_low = low_prices.rolling(window=length).min()
            highest_high = high_prices.rolling(window=length).max()
            return (lowest_low + highest_high) / 2
        
        # Calculate Conversion Line
        conversion_line = donchian(low_prices, high_prices, conversion_periods)
        
        # Calculate Base Line
        base_line = donchian(low_prices, high_prices, base_periods)
        
        # Calculate Leading Span 1
        lead_line1 = (conversion_line + base_line) / 2
        # close_prices = close_prices.shift(-displacement)
        # Calculate Leading Span 2
        lead_line2 = donchian(low_prices, high_prices, lagging_span2_periods)
        
        df[f'CL_{indc_num}'] = conversion_line
        df[f'BL_{indc_num}'] = base_line
        df[f'LL1_{indc_num}'] = lead_line1
        df[f'LL2_{indc_num}'] = lead_line2
        
        return df
    
    def keltner_channels(self, DF, length=20, multiplier=2.0, 
                         use_exponential=True, 
                         bands_style="Average True Range", 
                         atr_length=10, src_name = 'Open',
                         indc_num = 0):
        
        df = DF.copy()
        
        high_prices = df['High']
        low_prices = df['Low']
        
        if src_name not in ['Open', 'High', 'Low', 'Close', 'Volume']:
            self.src_name = src_name
            df = self.__create_source(df)
        close_prices =  df[src_name]
        
        if bands_style == "True Range":
            range_ma = np.abs(high_prices - low_prices)
        elif bands_style == "Average True Range":
            range_ma = ta.ATR(high_prices, low_prices, close_prices, atr_length)
        else:
            range_ma = np.mean(high_prices - low_prices)

        df[f'Middle_Band_{indc_num}'] = ta.EMA(close_prices, length) if use_exponential else ta.SMA(close_prices, length)
        df[f'Upper_Band_{indc_num}'] = df[{f'Middle_Band_{indc_num}'}] + range_ma * multiplier
        df[f'Lowe_Band_{indc_num}'] = df[{f'Middle_Band_{indc_num}'}] - range_ma * multiplier

        return df



class Entropy:
    def __init__(self, series):
        self.series = series.dropna().reset_index(drop=True)

    def check_stationarity(self, alpha=0.05):
        """
        Perform Augmented Dickey-Fuller test to check for stationarity.

        Parameters:
        - series: pandas Series, the time series column to test
        - alpha: float, significance level (default: 0.05)

        Returns:
        - dict with test statistics, p-value, critical values, and stationarity result
        """
        result = adfuller(self.series.dropna())  # Drop NaNs before applying the test
        test_statistic, p_value, _, _, critical_values, _ = result
        
        return {
            "ADF Statistic": test_statistic,
            "p-value": p_value,
            "Critical Values": critical_values,
            "Stationary": p_value < alpha  # True if p-value is less than significance level
        }


    def entropy(self, nbins):
        # Find the minimum and maximum values in x.
        lenth = len(self.series)
        minval = maxval = self.series[0]
        for i in range(1, lenth):
            if self.series[i] < minval:
                minval = self.series[i]
            if self.series[i] > maxval:
                maxval = self.series[i]
        
        # Calculate the scaling factor.
        factor = (nbins - 1e-10) / (maxval - minval + 1e-60)
        
        # Initialize bin counts.
        count = [0] * nbins
        
        # Count the number of cases in each bin.
        for i in range(lenth):
            k = int(factor * (self.series[i] - minval))
            count[k] += 1
        
        # Compute the entropy.
        s = 0.0
        for c in count:
            if c:
                p = c / lenth
                s += p * math.log(p)
        
        return -s / math.log(nbins)




# class GetDates:
#     def __init__(self, exchange = 'NSE', data_type = 'Equity'):
#         self.url = f"http://192.168.101.61/DataLakeAPI/v1/{exchange}/{data_type}/Ticker"
#         self.exchange = exchange
#         self.data_type = data_type

    




# api = ApiCall(data_type='Options')


# # df = api.get_data(symbol = ['NIFTY_50'], start_date = '2000-01-01', end_date = '2024-02-01')



# # df = api.get_data(symbol = ['NIFTY'], start_date = '2022-02-01', end_date = '2022-02-01', strike_price=[17000], option_type='CE', start_expiry='2022-02-03')

# df = api.get_data(symbol = ['NIFTY'], start_date = '2022-02-01', end_date = '2022-02-01', 
#                   strike_price=[17000], option_type='CE', start_expiry='2022-02-03', Time = ['11:55:00', '12:53:00'])
